import torch.nn as nn
import torch
from torch_geometric.nn.conv.gat_conv import GATConv
from torch_geometric.nn.conv.gcn_conv import GCNConv
from torch_geometric.nn.conv.rgcn_conv import RGCNConv
from torch_geometric.nn.conv.gin_conv import GINConv
import math
from torch_geometric.nn.conv.rgat_conv import RGATConv

import torch.nn.functional as F

import torch
import torch.nn as nn
import torch.nn.functional as F

class LayerLevelAttention(nn.Module):
    def __init__(self, layer_dim, num_layers):
        super(LayerLevelAttention, self).__init__()
        self.layer_dim = layer_dim
        self.num_layers = num_layers
        self.attention_weights = nn.Parameter(torch.Tensor(1, num_layers + 1))
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.attention_weights.data)

    def forward(self, layer_outputs):
        # layer_outputs: list of tensors [num_nodes, layer_dim] for each layer
        stack_layer_outputs = torch.stack(layer_outputs, dim=-1)  # [num_nodes, layer_dim, num_layers + 1]
        weights = F.softmax(self.attention_weights, dim=-1)  # Softmax across layers
        weighted_sum = torch.einsum('ndi,i->nd', stack_layer_outputs, weights.squeeze())  # [num_nodes, layer_dim]
        return weighted_sum


class SemanticAttentionLayer(nn.Module):
    def __init__(self, in_size, hidden_size, num_relations):
        super(SemanticAttentionLayer, self).__init__()
        self.in_size = in_size
        self.hidden_size = hidden_size
        self.num_relations = num_relations
        self.W = nn.Parameter(torch.Tensor(in_size, hidden_size))
        self.b = nn.Parameter(torch.Tensor(hidden_size))
        self.q = nn.Parameter(torch.Tensor(hidden_size, 1))
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.W.size(1))
        self.W.data.uniform_(-stdv, stdv)
        self.b.data.uniform_(-stdv, stdv)
        self.q.data.uniform_(-stdv, stdv)

    def forward(self, h):
        """
        h: Concatenated embeddings from different relations [num_relations, num_nodes, in_size]
        """
        Wh = torch.tanh(torch.matmul(h, self.W) + self.b)  # [num_relations, num_nodes, hidden_size]
        s = torch.matmul(Wh, self.q)  # [num_relations, num_nodes, 1]
        s = s.squeeze(2)  # [num_relations, num_nodes]
        weights = F.softmax(s, dim=0)  # Softmax over relations [num_relations, num_nodes]
        return weights

class HeteroBotGCN(nn.Module):
    def __init__(self, hidden_dim, des_size=768, tweet_size=768, num_prop_size=5, cat_prop_size=3, dropout=0.3,num_relations=2,num_layers=2):
        super(HeteroBotGCN, self).__init__()
        self.linear_relu_des = nn.Sequential(
            nn.Linear(des_size, hidden_dim // 4),
            nn.LeakyReLU()
        )
        self.linear_relu_tweet = nn.Sequential(
            nn.Linear(tweet_size, hidden_dim // 4),
            nn.LeakyReLU()
        )
        self.linear_relu_num_prop = nn.Sequential(
            nn.Linear(num_prop_size, hidden_dim // 4),
            nn.LeakyReLU()
        )
        self.linear_relu_cat_prop = nn.Sequential(
            nn.Linear(cat_prop_size, hidden_dim // 4),
            nn.LeakyReLU()
        )

        self.linear_relu_input = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.LeakyReLU()
        )
        self.linear_relu_output1 = nn.Sequential(
            nn.Linear(hidden_dim*3, hidden_dim),
            nn.LeakyReLU()
        )
        self.linear_output2 = nn.Linear(hidden_dim, 2)
        self.num_layers = num_layers
        self.gcn_layers = nn.ModuleList()
        for _ in range(num_relations):
            self.gcn_layers.append(nn.ModuleList([GCNConv(hidden_dim, hidden_dim) for _ in range(num_layers)]))
        self.semantic_attention = SemanticAttentionLayer(hidden_dim * (num_layers + 1), hidden_dim // 2, num_relations)
        self.dropout = nn.Dropout(p=dropout)




    def forward(self, data):
        edge_index, edge_type, batch = data.edge_index, data.edge_type, data.batch

        d = self.linear_relu_des(data.des_embedding)
        t = self.linear_relu_tweet(data.tweet_embedding)
        n = self.linear_relu_num_prop(data.num_property_embedding)
        c = self.linear_relu_cat_prop(data.cat_property_embedding)
        x = torch.cat((d, t, n, c), dim=1)

        x = self.linear_relu_input(x)

        all_relation_embeddings = []
        for relation_index, gcn_layer_group in enumerate(self.gcn_layers):
            relation_embeddings = [x]  # Include input features as the 0-th layer output
            mask = edge_type == relation_index
            edge_index_i = edge_index[:, mask]
            for gcn_layer in gcn_layer_group:
                x_i = gcn_layer(relation_embeddings[-1], edge_index_i)  # Apply GCN layer
                x_i = self.dropout(x_i)
                relation_embeddings.append(x_i)  # Append output of this layer
            # Concatenate outputs of all layers for this relation
            concatenated_embeddings = torch.cat(relation_embeddings, dim=1)
            all_relation_embeddings.append(concatenated_embeddings.unsqueeze(0))

        # Now, all_relation_embeddings is a list of tensors with shape [1, num_nodes, hidden_dim * (num_layers + 1)]
        relation_embeddings = torch.cat(all_relation_embeddings,
                                        dim=0)  # [num_relations, num_nodes, hidden_dim * (num_layers + 1)]

        # Semantic attention and final processing remain similar
        weights = self.semantic_attention(relation_embeddings)
        x_final = torch.einsum('rni,rn->ni', relation_embeddings, weights)

        x_center_node = x_final[data.x_center_features == True]

        x = self.linear_relu_output1(x_center_node)

        x = self.linear_output2(x)


        return x


class LayerBotGCN(nn.Module):
    def __init__(self, hidden_dim, des_size=768, tweet_size=768, num_prop_size=5, cat_prop_size=3, dropout=0.3,
                 num_relations=2, num_layers=2):
        super(LayerBotGCN, self).__init__()
        self.linear_relu_des = nn.Sequential(nn.Linear(des_size, hidden_dim // 4), nn.LeakyReLU())
        self.linear_relu_tweet = nn.Sequential(nn.Linear(tweet_size, hidden_dim // 4), nn.LeakyReLU())
        self.linear_relu_num_prop = nn.Sequential(nn.Linear(num_prop_size, hidden_dim // 4), nn.LeakyReLU())
        self.linear_relu_cat_prop = nn.Sequential(nn.Linear(cat_prop_size, hidden_dim // 4), nn.LeakyReLU())
        self.linear_relu_input = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.LeakyReLU())
        self.linear_relu_output1 = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.LeakyReLU())
        self.linear_output2 = nn.Linear(hidden_dim, 2)
        self.num_layers = num_layers
        self.gcn_layers = nn.ModuleList()
        self.layer_attention = nn.ModuleList()
        for _ in range(num_relations):
            self.gcn_layers.append(nn.ModuleList([GATConv(hidden_dim // 4 * 4, hidden_dim) for _ in range(num_layers)]))
            self.layer_attention.append(LayerLevelAttention(hidden_dim, num_layers))
        self.semantic_attention = SemanticAttentionLayer(hidden_dim, hidden_dim // 2, num_relations)
        self.dropout = nn.Dropout(p=dropout)

    def forward(self, data):
        edge_index, edge_type, batch = data.edge_index, data.edge_type, data.batch

        d = self.linear_relu_des(data.des_embedding)
        t = self.linear_relu_tweet(data.tweet_embedding)
        n = self.linear_relu_num_prop(data.num_property_embedding)
        c = self.linear_relu_cat_prop(data.cat_property_embedding)
        x = torch.cat((d, t, n, c), dim=1)

        x = self.linear_relu_input(x)

        all_relation_embeddings = []
        for relation_index, (gcn_layer_group, attention_layer) in enumerate(zip(self.gcn_layers, self.layer_attention)):
            relation_layer_outputs = [x]
            mask = edge_type == relation_index
            edge_index_i = edge_index[:, mask]
            for gcn_layer in gcn_layer_group:
                x_i = gcn_layer(relation_layer_outputs[-1], edge_index_i)
                x_i = self.dropout(x_i)
                relation_layer_outputs.append(x_i)

            relation_embedding = attention_layer(relation_layer_outputs)
            all_relation_embeddings.append(relation_embedding.unsqueeze(0))

        relation_embeddings = torch.cat(all_relation_embeddings, dim=0)
        weights = self.semantic_attention(relation_embeddings)
        x_final = torch.einsum('rni,rn->ni', relation_embeddings, weights)

        x = self.linear_relu_output1(x_final)
        x = self.linear_output2(x)

        return x

class MeanBotGCN(nn.Module):
    def __init__(self, hidden_dim, des_size=768, tweet_size=768, num_prop_size=5, cat_prop_size=3, dropout=0.3, num_relations=2, num_layers=2):
        super(MeanBotGCN, self).__init__()
        self.linear_relu_des = nn.Sequential(
            nn.Linear(des_size, hidden_dim // 4),
            nn.LeakyReLU()
        )
        self.linear_relu_tweet = nn.Sequential(
            nn.Linear(tweet_size, hidden_dim // 4),
            nn.LeakyReLU()
        )
        self.linear_relu_num_prop = nn.Sequential(
            nn.Linear(num_prop_size, hidden_dim // 4),
            nn.LeakyReLU()
        )
        self.linear_relu_cat_prop = nn.Sequential(
            nn.Linear(cat_prop_size, hidden_dim // 4),
            nn.LeakyReLU()
        )

        self.linear_relu_input = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.LeakyReLU()
        )
        self.linear_relu_output1 = nn.Sequential(
            nn.Linear(hidden_dim * 3, hidden_dim),
            nn.LeakyReLU()
        )
        self.linear_output2 = nn.Linear(hidden_dim, 2)
        self.num_layers = num_layers
        self.gcn_layers = nn.ModuleList()
        for _ in range(num_relations):
            self.gcn_layers.append(nn.ModuleList([GCNConv(hidden_dim, hidden_dim) for _ in range(num_layers)]))
        self.dropout = nn.Dropout(p=dropout)

    def forward(self, data):
        edge_index, edge_type, batch = data.edge_index, data.edge_type, data.batch

        d = self.linear_relu_des(data.des_embedding)
        t = self.linear_relu_tweet(data.tweet_embedding)
        n = self.linear_relu_num_prop(data.num_property_embedding)
        c = self.linear_relu_cat_prop(data.cat_property_embedding)
        x = torch.cat((d, t, n, c), dim=1)

        x = self.linear_relu_input(x)

        all_relation_embeddings = []
        for relation_index, gcn_layer_group in enumerate(self.gcn_layers):
            relation_embeddings = [x]  # Include input features as the 0-th layer output
            mask = edge_type == relation_index
            edge_index_i = edge_index[:, mask]
            for gcn_layer in gcn_layer_group:
                x_i = gcn_layer(relation_embeddings[-1], edge_index_i)  # Apply GCN layer
                x_i = self.dropout(x_i)
                relation_embeddings.append(x_i)  # Append output of this layer
            # Concatenate outputs of all layers for this relation
            concatenated_embeddings = torch.cat(relation_embeddings, dim=1)
            all_relation_embeddings.append(concatenated_embeddings.unsqueeze(0))

        # [num_relations, num_nodes, hidden_dim * (num_layers + 1)]
        relation_embeddings = torch.cat(all_relation_embeddings, dim=0)

        # Apply mean pooling across the relation dimension
        x_final = torch.mean(relation_embeddings, dim=0)  # [num_nodes, hidden_dim * (num_layers + 1)]

        x_center_node = x_final[data.x_center_features == True]

        x = self.linear_relu_output1(x_center_node)
        x = self.linear_output2(x)

        return x

class BotRGCN(nn.Module):
    def __init__(self, hidden_dim,
                 des_size=768,
                 tweet_size=768,
                 num_prop_size=5,
                 cat_prop_size=3,
                 dropout=0.3,
                 num_relations=2):

        super(BotRGCN, self).__init__()
        self.linear_relu_des = nn.Sequential(
            nn.Linear(des_size, hidden_dim // 4),
            nn.LeakyReLU()
        )

        self.linear_relu_tweet = nn.Sequential(
            nn.Linear(tweet_size, hidden_dim // 4),
            nn.LeakyReLU()
        )

        self.linear_relu_num_prop = nn.Sequential(
            nn.Linear(num_prop_size, hidden_dim // 4),
            nn.LeakyReLU()
        )

        self.linear_relu_cat_prop = nn.Sequential(
            nn.Linear(cat_prop_size, hidden_dim // 4),
            nn.LeakyReLU()
        )

        self.linear_relu_input = nn.Sequential(
            nn.Linear(128, hidden_dim),
            nn.LeakyReLU()
        )

        self.linear_relu_output1 = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.LeakyReLU()
        )

        self.linear_output2 = nn.Linear(hidden_dim, 2)
        self.rgcn1 = RGCNConv(hidden_dim, hidden_dim, num_relations=num_relations)
        self.rgcn2 = RGCNConv(hidden_dim, hidden_dim, num_relations=num_relations)
        self.dropout = nn.Dropout(p=dropout)

    def forward(self, data):
        edge_index, edge_type, batch = data.edge_index, data.edge_type, data.batch

        d = self.linear_relu_des(data.des_embedding)
        t = self.linear_relu_tweet(data.tweet_embedding)
        n = self.linear_relu_num_prop(data.num_property_embedding)
        c = self.linear_relu_cat_prop(data.cat_property_embedding)
        x = torch.cat((d, t, n, c), dim=1)
        x = self.linear_relu_input(x)
        x = self.rgcn1(x, edge_index, edge_type)
        x = self.dropout(x)
        x = self.rgcn2(x, edge_index, edge_type)
        x = self.linear_relu_output1(x)
        x = self.linear_output2(x)
        x = x[data.x_center_features == True]



        return x

class BotGCN(nn.Module):
    def __init__(self, hidden_dim, des_size=768, tweet_size=768, num_prop_size=5, cat_prop_size=3, dropout=0.3):
        super(BotGCN, self).__init__()
        self.linear_relu_des = nn.Sequential(
            nn.Linear(des_size, hidden_dim // 4),
            nn.LeakyReLU()
        )
        self.linear_relu_tweet = nn.Sequential(
            nn.Linear(tweet_size, hidden_dim // 4),
            nn.LeakyReLU()
        )
        self.linear_relu_num_prop = nn.Sequential(
            nn.Linear(num_prop_size, hidden_dim // 4),
            nn.LeakyReLU()
        )
        self.linear_relu_cat_prop = nn.Sequential(
            nn.Linear(cat_prop_size, hidden_dim // 4),
            nn.LeakyReLU()
        )

        self.linear_relu_input = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.LeakyReLU()
        )
        self.linear_relu_output1 = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.LeakyReLU()
        )
        self.linear_output2 = nn.Linear(hidden_dim, 2)

        self.gcn1 = GCNConv(hidden_dim, hidden_dim)
        self.gcn2 = GCNConv(hidden_dim, hidden_dim)
        self.dropout = nn.Dropout(p=dropout)

    def forward(self, data):
        edge_index, edge_type, batch = data.edge_index, data.edge_type, data.batch

        d = self.linear_relu_des(data.des_embedding)
        t = self.linear_relu_tweet(data.tweet_embedding)
        n = self.linear_relu_num_prop(data.num_property_embedding)
        c = self.linear_relu_cat_prop(data.cat_property_embedding)
        x = torch.cat((d, t, n, c), dim=1)

        x = self.dropout(x)
        x = self.linear_relu_input(x)
        x = self.gcn1(x, edge_index)
        x = self.dropout(x)
        x = self.gcn2(x, edge_index)
        x = self.linear_relu_output1(x)
        x = self.linear_output2(x)
        x = x[data.x_center_features == True]
        return x

class BotGAT(nn.Module):
    def __init__(self, hidden_dim, des_size=768, tweet_size=768, num_prop_size=5, cat_prop_size=3, dropout=0.3):
        super(BotGAT, self).__init__()
        self.linear_relu_des = nn.Sequential(
            nn.Linear(des_size, hidden_dim // 4),
            nn.LeakyReLU()
        )
        self.linear_relu_tweet = nn.Sequential(
            nn.Linear(tweet_size, hidden_dim // 4),
            nn.LeakyReLU()
        )
        self.linear_relu_num_prop = nn.Sequential(
            nn.Linear(num_prop_size, hidden_dim // 4),
            nn.LeakyReLU()
        )
        self.linear_relu_cat_prop = nn.Sequential(
            nn.Linear(cat_prop_size, hidden_dim // 4),
            nn.LeakyReLU()
        )

        self.linear_relu_input = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.LeakyReLU()
        )
        self.linear_relu_output1 = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.LeakyReLU()
        )
        self.linear_output2 = nn.Linear(hidden_dim, 2)

        self.gat1 = GATConv(hidden_dim, hidden_dim // 4, heads=4)
        self.gat2 = GATConv(hidden_dim, hidden_dim)
        self.dropout = nn.Dropout(p=dropout)

    def forward(self, data):
        edge_index, edge_type, batch = data.edge_index, data.edge_type, data.batch

        d = self.linear_relu_des(data.des_embedding)
        t = self.linear_relu_tweet(data.tweet_embedding)
        n = self.linear_relu_num_prop(data.num_property_embedding)
        c = self.linear_relu_cat_prop(data.cat_property_embedding)
        x = torch.cat((d, t, n, c), dim=1)

        x = self.linear_relu_input(x)
        x = self.gat1(x, edge_index)
        x = self.dropout(x)
        #x = self.gat2(x, edge_index)
        x = self.linear_relu_output1(x)
        x = self.linear_output2(x)
        x = x[data.x_center_features == True]
        return x

class MLP(nn.Module):
    def __init__(self, hidden_dim,
                 des_size=768,
                 tweet_size=768,
                 num_prop_size=5,
                 cat_prop_size=3,
                 dropout=0.3,
                 num_relations=2):

        super(MLP, self).__init__()
        self.linear_relu_des = nn.Sequential(
            nn.Linear(des_size, hidden_dim // 4),
            nn.LeakyReLU()
        )

        self.linear_relu_tweet = nn.Sequential(
            nn.Linear(tweet_size, hidden_dim // 4),
            nn.LeakyReLU()
        )

        self.linear_relu_num_prop = nn.Sequential(
            nn.Linear(num_prop_size, hidden_dim // 4),
            nn.LeakyReLU()
        )

        self.linear_relu_cat_prop = nn.Sequential(
            nn.Linear(cat_prop_size, hidden_dim // 4),
            nn.LeakyReLU()
        )

        self.linear_relu_input = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.LeakyReLU()
        )

        self.linear_relu_output1 = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.LeakyReLU()
        )
        self.linear_relu_output2 = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 4),
            nn.LeakyReLU()
        )
        self.linear_output2 = nn.Linear(hidden_dim// 4, 2)
        self.dropout = nn.Dropout(p=dropout)


    def forward(self, des, tweet, num_prop, cat_prop, edge_index, edge_type):



        d = self.linear_relu_des(des)
        t = self.linear_relu_tweet(tweet)
        n = self.linear_relu_num_prop(num_prop)
        c = self.linear_relu_cat_prop(cat_prop)
        x = torch.cat((d, t, n, c), dim=1)

        x = self.linear_relu_input(x)
        x = self.linear_relu_output1(x)
        x = self.dropout(x)
        x1 = self.linear_relu_output2(x)
        x = self.linear_output2(x1)

        return x,x1
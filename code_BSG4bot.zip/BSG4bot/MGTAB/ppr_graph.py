# coding=utf-8
from __future__ import print_function
import numpy as np

from tqdm import tqdm
import os
import networkx as nx
import scipy.sparse as ssp
import torch
import torch.nn.functional as F
from torch_geometric.data import Data, Dataset, InMemoryDataset
import warnings


warnings.simplefilter('ignore', ssp.SparseEfficiencyWarning)
cur_dir = os.path.dirname(os.path.realpath(__file__))
torch.set_printoptions(precision=8)

class MyPPRGraphDataset(Dataset):
    def __init__(self, root, entire_graph, ppr_matrix, node_idx, transform=None, pre_transform=None):
        self.root = root
        super(MyPPRGraphDataset, self).__init__(root, transform, pre_transform)
        self.entire_graph = entire_graph
        self.ppr_matrix = ppr_matrix
        self.node_idx = node_idx
        self.cached = {}  # 存储预处理后的子图数据

        self._process()
    @property
    def raw_file_names(self):
        return []

    @property
    def processed_file_names(self):
        return []

    def _download(self):
        pass

    def _process(self):
        # processed_dir = os.path.join(self.root, "processed_subgraph")
        # os.makedirs(processed_dir, exist_ok=True)
        for idx in tqdm(range (len(self.node_idx))):
            subgraph = create_ppr_subgraph(self.entire_graph, self.ppr_matrix, self.node_idx, idx)
            subgraph_data = nx_to_PYGGraph(subgraph, self.entire_graph.y[self.node_idx[idx]])
            self.cached[idx] = subgraph_data
    def len(self):
        pass
    def get(self,idx):
        pass

    def __len__(self) :
        r"""The number of examples in the dataset."""
        return len(self.node_idx)


    def __getitem__(self, idx):
        if isinstance(idx, int):
            key = idx  # single index
        else:
            key = idx[0]  # assuming idx is a list

        if key not in self.cached:
            subgraph_label = self.entire_graph.y[self.node_idx[idx]]

            ppr_subgraph= create_ppr_subgraph(self.entire_graph,self.ppr_matrix,self.node_idx,idx)
            data = nx_to_PYGGraph(ppr_subgraph,subgraph_label)

            self.cached[key]=data

        return self.cached[key]

    # def get(self,idx):
    #     subgraph_label = self.entire_graph.y[self.node_idx[idx]]
    #
    #     ppr_subgraph = create_ppr_subgraph(self.entire_graph, self.ppr_matrix, self.node_idx, idx)
    #     data = nx_to_PYGGraph(ppr_subgraph, subgraph_label)
    #     return data




#创建子图，中心节点和ppr节点连边

def create_ppr_subgraph(data,ppr_matrix,node_idx,idx):

    center_node = int(node_idx[idx])

    #node_features = torch.cat((data.des_embedding, data.tweet_embedding, data.num_property_embedding, data.cat_property_embedding), dim=1).numpy()

    subgraph = nx.MultiGraph()

    sub_nodes = {center_node: 0}
    subgraph.add_node(0, features=center_node, original_id=center_node, center=True)

    '''添加（center_node，neighbors）边'''
    for etype, ppr_mat in ppr_matrix.items():
        ppr_neighbors = ppr_mat[idx].nonzero()[1]
        for v in ppr_neighbors:
            if v not in sub_nodes:
                sub_nodes[v] = len(sub_nodes)
                subgraph.add_node(sub_nodes[v], features=v, original_id=v, center=False)
            if v!=center_node:
                subgraph.add_edge(sub_nodes[center_node], sub_nodes[v], relation=etype)

    '''添加（neighbors，neighbors）在原图中的直连边'''
    neighbors = list(sub_nodes.keys())
    neighbors.remove(center_node)  # 移除中心节点，只考虑邻居节点间的边

    edge_index_np = data.edge_index.numpy()
    edge_type_np = data.edge_type.numpy()

    for i in range(len(neighbors)):
        for j in range(i + 1, len(neighbors)):  # 仅考虑未被检查过的节点对，避免重复
            node_i = neighbors[i]
            node_j = neighbors[j]
            # 检查node_i到node_j和node_j到node_i的所有可能边
            for direction in [(node_i, node_j), (node_j, node_i)]:
                mask = np.logical_and(edge_index_np[0] == direction[0], edge_index_np[1] == direction[1])
                edge_types = edge_type_np[mask]

                # 对每种边类型，如果存在，则添加到子图中
                for edge_type in edge_types:
                    subgraph.add_edge(sub_nodes[direction[0]], sub_nodes[direction[1]], relation=edge_type)

    return subgraph


def create_enhanced_ppr_subgraph(data, ppr_matrix, node_idx, idx,topk=4):
    center_node = int(node_idx[idx])
    node_features = torch.cat(
        (data.des_embedding, data.tweet_embedding, data.num_property_embedding, data.cat_property_embedding),
        dim=1).numpy()

    subgraph = nx.MultiGraph()

    sub_nodes = {center_node: 0}
    subgraph.add_node(0, features=node_features[center_node], original_id=center_node, center=True)

    '''添加（center_node，neighbors）边'''
    for etype, ppr_mat in ppr_matrix.items():
        ppr_neighbors = ppr_mat[center_node].nonzero()[1]
        for v in ppr_neighbors:
            if v not in sub_nodes:
                sub_nodes[v] = len(sub_nodes)
                subgraph.add_node(sub_nodes[v], features=node_features[v], original_id=v, center=False)
            if v != center_node:
                subgraph.add_edge(sub_nodes[center_node], sub_nodes[v], relation=etype)

    '''添加相似度topk节点'''
    node_representations = data.pretrained_results
    center_node_representation = node_representations[center_node].unsqueeze(0)
    cos_similarities = F.cosine_similarity(center_node_representation, node_representations, dim=1)
    # 获取相似度最高的topk个节点及其相似度值
    topk_values, topk_indices = torch.topk(cos_similarities, k=topk + 1)  # +1是因为目标节点与自己的相似度为1
    # 排除目标节点自身
    mask = topk_indices != center_node
    topk_values, topk_indices = topk_values[mask][:topk].numpy(), topk_indices[mask][:topk].numpy()
    for v in topk_indices:
        if v not in sub_nodes:
            sub_nodes[v] = len(sub_nodes)
            subgraph.add_node(sub_nodes[v], features=node_features[v], original_id=v, center=False)
        for edge_type in torch.unique(data.edge_type):
            subgraph.add_edge(sub_nodes[center_node], sub_nodes[v], relation=edge_type)

    del node_representations,\
        center_node_representation,\
        cos_similarities,\
        topk_values,\
        topk_indices

    '''添加（neighbors，neighbors）在原图中的直连边'''
    neighbors = list(sub_nodes.keys())
    neighbors.remove(center_node)  # 移除中心节点，只考虑邻居节点间的边

    edge_index_np = data.edge_index.numpy()
    edge_type_np = data.edge_type.numpy()

    for i in range(len(neighbors)):
        for j in range(i + 1, len(neighbors)):  # 仅考虑未被检查过的节点对，避免重复
            node_i = neighbors[i]
            node_j = neighbors[j]
            # 检查node_i到node_j和node_j到node_i的所有可能边
            for direction in [(node_i, node_j), (node_j, node_i)]:
                mask = np.logical_and(edge_index_np[0] == direction[0], edge_index_np[1] == direction[1])
                edge_types = edge_type_np[mask]

                # 对每种边类型，如果存在，则添加到子图中
                for edge_type in edge_types:
                    subgraph.add_edge(sub_nodes[direction[0]], sub_nodes[direction[1]], relation=edge_type)

    return subgraph

# convert networkx graph to pytorch_geometric data format
def nx_to_PYGGraph(g,g_label):
    y = g_label

    node_features = nx.get_node_attributes(g, 'features')
    x = torch.tensor(np.array(list(node_features.values())), dtype=torch.long)

    center_features= nx.get_node_attributes(g, 'center')
    x_center_features= torch.tensor(np.array(list(center_features.values())), dtype=torch.bool)

    num_nodes = len(node_features)


    edge_index_list = []  # 用于存储边的索引
    edge_type_list = []  # 用于存储边的类型

    # 遍历图中的每条边及其属性
    for u, v, attr in g.edges(data=True):
        edge_index_list.append((u, v))  # 添加边的起点和终点到列表
        edge_type_list.append(attr['relation'])  # 添加边的类型到列表

    # 将边的索引列表转换为张量形式
    edge_index = torch.LongTensor(edge_index_list).t()

    # 将边的类型列表转换为张量形式
    edge_type = torch.LongTensor(edge_type_list)

    data = Data(x, edge_index, y=y)
    data.edge_type = edge_type
    data.graph_size = num_nodes
    data.x_center_features =x_center_features
    data.location = 0
    return data











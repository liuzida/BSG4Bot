import os
from argparse import ArgumentParser
from utils import null_metrics, calc_metrics, is_better
import torch
from dataset import get_train_data
from torch_geometric.loader import NeighborLoader
from torch.utils.data import DataLoader, TensorDataset
from tqdm import tqdm
import torch.nn as nn
import random
import numpy as np
from  model import MLP

parser = ArgumentParser()
parser.add_argument('--dataset', type=str, default='Twibot-22')
parser.add_argument('--visible', type=bool, default=True)
parser.add_argument('--hidden_dim', type=int, default=128)
parser.add_argument('--max_epoch', type=int, default=200)
parser.add_argument('--batch_size', type=int, default=256)
parser.add_argument('--no_up', type=int, default=50)
parser.add_argument('--lr', type=float, default=1e-3)
parser.add_argument('--weight_decay', type=float, default=1e-5)
parser.add_argument('--dropout', type=float, default=0.3)
args = parser.parse_args()

dataset_name = args.dataset
visible = args.visible
device = torch.device('cuda')

assert dataset_name in ['Twibot-20', 'Twibot-22']

hidden_dim = args.hidden_dim
dropout = args.dropout
lr = args.lr
weight_decay = args.weight_decay
max_epoch = args.max_epoch
batch_size = args.batch_size
no_up = args.no_up


def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    random.seed(seed)
    print('set seed for random numpy and torch')

def forward_one_epoch(epoch, model, optimizer, loss_fn, train_loader, val_loader):
    print(epoch)
    model.train()
    all_label = []
    all_pred = []
    ave_loss = 0.0
    cnt = 0.0
    count = 0
    for batch in train_loader:
        optimizer.zero_grad()
        batch = batch.to(device)
        n_batch = batch.batch_size
        out,embedding = model(batch.des_embedding,
                    batch.tweet_embedding,
                    batch.num_property_embedding,
                    batch.cat_property_embedding,
                    batch.edge_index,
                    batch.edge_type)

        label = batch.y[:n_batch]
        out = out[:n_batch]
        all_label += label.data
        all_pred += out
        loss = loss_fn(out, label)
        ave_loss += loss.item() * n_batch
        cnt += n_batch
        loss.backward()
        nn.utils.clip_grad_value_(model.parameters(), 1000)
        optimizer.step()
        count = count +1

    ave_loss /= cnt
    all_label = torch.stack(all_label)
    all_pred = torch.stack(all_pred)
    metrics, plog = calc_metrics(all_label, all_pred)
    plog = 'Epoch-{} train loss: {:.6}'.format(epoch, ave_loss) + plog
    if visible:
        print(plog)
    val_metrics = validation(epoch, 'validation', model, loss_fn, val_loader)
    return val_metrics


@torch.no_grad()
def validation(epoch, name, model, loss_fn, loader,pretrained=False):
    model.eval()
    all_label = []
    all_pred = []
    ave_loss = 0.0
    cnt = 0.0
    pretrained_embeddings = []
    for batch in loader:
        batch = batch.to(device)
        n_batch = batch.batch_size
        out,embedding = model(batch.des_embedding,
                    batch.tweet_embedding,
                    batch.num_property_embedding,
                    batch.cat_property_embedding,
                    batch.edge_index,
                    batch.edge_type)
        if pretrained==True:
            pretrained_embeddings.append(embedding.cpu())

        label = batch.y[:n_batch]
        out = out[:n_batch]
        all_label += label.data
        all_pred += out
        loss = loss_fn(out, label)
        ave_loss += loss.item() * n_batch
        cnt += n_batch
    ave_loss /= cnt
    all_label = torch.stack(all_label)
    all_pred = torch.stack(all_pred)
    metrics, plog = calc_metrics(all_label, all_pred)
    plog = 'Epoch-{} {} loss: {:.6}'.format(epoch, name, ave_loss) + plog
    if visible:
        print(plog)
    if pretrained == True:
        return metrics,pretrained_embeddings
    else:
        return metrics

def train(seed):
    train_loader = NeighborLoader(data,
                                  num_neighbors=[0] * 4,
                                  batch_size=batch_size,
                                  input_nodes=data.train_idx,
                                  shuffle=True,
                                  )
    val_loader = NeighborLoader(data,
                                num_neighbors=[0] * 4,
                                batch_size=batch_size,
                                input_nodes=data.val_idx,
                                )

    test_loader = NeighborLoader(data,
                                 num_neighbors=[0] * 4,
                                 batch_size=batch_size,
                                 input_nodes=data.test_idx)

    pretrained_loader=NeighborLoader(data,
                                 num_neighbors=[0] * 4,
                                 batch_size=batch_size,
                                 input_nodes=data.pre_trained_test_idx)


    mode='mlp'
    model = MLP(hidden_dim=hidden_dim,
                dropout=dropout,
                num_prop_size=data.num_property_embedding.shape[-1],
                cat_prop_size=data.cat_property_embedding.shape[-1]).to(device)

    best_val_metrics = null_metrics()
    best_state_dict = None
    loss_fn = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    pbar = tqdm(range(max_epoch), ncols=0)
    cnt = 0

    for epoch in pbar:

        val_metrics = forward_one_epoch(epoch, model, optimizer, loss_fn, train_loader, val_loader)
        print(val_metrics)
        if is_better(val_metrics, best_val_metrics):
            best_val_metrics = val_metrics
            best_state_dict = model.state_dict()
            cnt = 0
        else:
            cnt += 1
        pbar.set_postfix_str('val acc {} no up cnt {}'.format(val_metrics['acc'], cnt))
        if cnt == no_up:
            break
    model.load_state_dict(best_state_dict)

    test_metrics = validation(max_epoch, 'test', model, loss_fn, test_loader,pretrained=False)

    #获取mlp上数据集中所有节点的embedding，包括训练，验证和测试集
    pretrained_metrics,pretrained_embeddings = validation(max_epoch, 'test', model, loss_fn, pretrained_loader,pretrained=True)
    pretrained_embeddings=torch.cat(pretrained_embeddings, dim=0)
    torch.save(pretrained_embeddings, 'pretrained/{}.pt'.format(dataset_name,'pretrained_embedding' + str(seed)))


    torch.save(best_state_dict, 'saved_model/{}_{}_{}.pt'.format(dataset_name,mode,'user'+str(seed)))
    with open('result/' + dataset_name+mode+str(seed), 'w') as file:
        for key, value in test_metrics.items():
            print(key, value, file=file)



if __name__ == '__main__':
    for i in range(4):
        data = get_train_data(dataset_name)

        set_seed(i)
        train(i)

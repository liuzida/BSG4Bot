import networkx as nx
import numba
import numpy as np
import torch
import scipy.sparse as sp
from sklearn.metrics.pairwise import cosine_similarity
from scipy.sparse import find
from collections import defaultdict
from tqdm import tqdm


@numba.njit(cache=True, locals={'_val': numba.float32, 'res': numba.float32, 'res_vnode': numba.float32})
def _calc_ppr_node(inode, indptr, indices, deg, alpha, epsilon, N):  # Added N as a parameter to represent the total number of nodes
    alpha_eps = alpha * epsilon
    f32_0 = numba.float32(0)
    p = {inode: f32_0}
    r = {}
    r[inode] = alpha
    q = [inode]

    while len(q) > 0:
        unode = q.pop()

        res = r[unode] if unode in r else f32_0
        if unode in p:
            p[unode] += res
        else:
            p[unode] = res
        r[unode] = f32_0
        for vnode in indices[indptr[unode]:indptr[unode + 1]]:
            if deg[unode] == 0:
                _val = (1 - alpha) * res / max(deg[unode], 1)
            else:
                _val = (1 - alpha) * res / deg[unode]  
            if vnode in r:
                r[vnode] += _val
            else:
                r[vnode] = _val

            res_vnode = r[vnode] if vnode in r else f32_0
            if res_vnode >= alpha_eps * deg[vnode]:
                if vnode not in q:
                    q.append(vnode)

    return list(p.keys()), list(p.values())




@numba.njit(cache=True)
def calc_ppr(indptr, indices, deg, alpha, epsilon, nodes):
    js = []
    vals = []
    for i, node in enumerate(nodes):
        j, val = _calc_ppr_node(node, indptr, indices, deg, alpha, epsilon)
        js.append(j)
        vals.append(val)
    return js, vals





@numba.njit(cache=True, parallel=True)
def calc_ppr_topk_parallel(indptr, indices, deg, alpha, epsilon, nodes, topk, N):
    js = [np.zeros(0, dtype=np.int64)] * len(nodes) 
    vals = [np.zeros(0, dtype=np.float32)] * len(nodes)

    for i in numba.prange(len(nodes)):
        j, val = _calc_ppr_node(nodes[i], indptr, indices, deg, alpha, epsilon, N)
        j_np, val_np = np.array(j), np.array(val)

        idx_topk = np.argsort(val_np)[-val_np.shape[0]:]
        js[i] = j_np[idx_topk].astype(np.int64)  
        vals[i] = val_np[idx_topk]

    return js, vals



def ppr_topk(adj_matrix, alpha, epsilon, nodes, topk):
    """Calculate the PPR matrix approximately using Anderson."""
    N = max(adj_matrix.shape[0],adj_matrix.shape[1])
    out_degree = np.sum(adj_matrix > 0, axis=1).A1

    nnodes = max(adj_matrix.shape[0],adj_matrix.shape[1])

    neighbors, weights = calc_ppr_topk_parallel(adj_matrix.indptr, adj_matrix.indices, out_degree,
                                                numba.float32(alpha), numba.float32(epsilon), nodes, topk,N)
    weights = [w / np.sum(w) for w in weights]

    return construct_sparse(neighbors, weights, (len(nodes), nnodes),alpha)


def construct_sparse(neighbors, weights, shape,alpha):
    i = np.repeat(np.arange(len(neighbors)), np.fromiter(map(len, neighbors), dtype=int))
    j = np.concatenate(neighbors)
    data = np.concatenate(weights)
    return sp.coo_matrix((data, (i, j)), shape)




def get_sparse_matrices(edge_type, edge_index, directed):
    if not isinstance(edge_index, np.ndarray):
        edge_index = edge_index.numpy()
    if not isinstance(edge_type, np.ndarray):
        edge_type = edge_type.numpy()

    num_node = np.max(edge_index) + 1
    num_edge_types = np.max(edge_type) + 1

    subgraph_matrices_csr = {}

    for edge_type_id in range(num_edge_types):
        type_mask = edge_type == edge_type_id
        subgraph_edges = edge_index[:, type_mask]

        if directed:
            matrix_csr = sp.csr_matrix((np.ones(subgraph_edges.shape[1]), (subgraph_edges[0], subgraph_edges[1])),
                                       shape=[num_node, num_node])
        else:
            undirected_edges = np.hstack([subgraph_edges, subgraph_edges[[1, 0]]])
            matrix_csr = sp.csr_matrix((np.ones(undirected_edges.shape[1]), (undirected_edges[0], undirected_edges[1])),
                                       shape=[num_node, num_node])
        subgraph_matrices_csr[edge_type_id] = matrix_csr

    return subgraph_matrices_csr


def get_biased_ppr_matrix(data, ppr_matrix, topk):

    node_features = data.pretrained_results.numpy()  
    rows, cols, vals = [], [], []

    for i in range(ppr_matrix.shape[0]):

        neighbors = ppr_matrix[i].nonzero()[1]
        ppr_values = ppr_matrix[i].data

        if len(neighbors) == 0:
            continue

        center_feature = node_features[i].reshape(1, -1)
        neighbor_features = node_features[neighbors]
        similarities = cosine_similarity(center_feature, neighbor_features).flatten()

        normalized_similarities = (similarities + 1) / 2
        scores = normalized_similarities *1 + ppr_values

        topk_indices = np.argsort(scores)[-topk:]
        topk_neighbors = neighbors[topk_indices]
        topk_scores = scores[topk_indices]

        rows.extend([i] * len(topk_neighbors))
        cols.extend(topk_neighbors)
        vals.extend(topk_scores)

    new_sparse_matrix = sp.coo_matrix((vals, (rows, cols)), shape=ppr_matrix.shape)

    return new_sparse_matrix



def topk_ppr_matrix(data, alpha, eps, idx, topk, normalization='row',directed=True):



    adj_matrix_all = get_sparse_matrices(data.edge_type,data.edge_index,directed)

    """Create a sparse matrix where each node has up to the topk PPR neighbors and their weights."""


    topk_matrix = {}
    for edge_type, adj_matrix in adj_matrix_all.items():

        ppr_matrix = ppr_topk(adj_matrix, alpha, eps, idx.numpy(), topk).tocsr()

        if normalization == 'sym':
            # Assume undirected (symmetric) adjacency matrix
            deg = adj_matrix.sum(1).A1
            deg_sqrt = np.sqrt(np.maximum(deg, 1e-12))
            deg_inv_sqrt = 1. / deg_sqrt
            row, col = topk_matrix.nonzero()
            topk_matrix.data = deg_sqrt[idx[row]] * topk_matrix.data * deg_inv_sqrt[col]

        elif normalization == 'col':
            # Assume undirected (symmetric) adjacency matrix
            deg = adj_matrix.sum(1).A1
            deg_inv = 1. / np.maximum(deg, 1e-12)
            row, col = topk_matrix.nonzero()
            topk_matrix.data = deg[idx[row]] * topk_matrix.data * deg_inv[col]

        elif normalization == 'row':
            pass
        else:
            raise ValueError(f"Unknown PPR normalization: {normalization}")

        biased_ppr_matrix = get_biased_ppr_matrix(data, ppr_matrix, topk).tocsr()

        topk_matrix[edge_type] = biased_ppr_matrix



    return topk_matrix



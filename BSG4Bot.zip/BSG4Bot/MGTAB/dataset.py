import os
import torch
import os.path as osp
from torch_geometric.data import Data
from sklearn.utils import shuffle
import numpy as np
from MGTAB_Dataset import MGTAB,MGTABlarge
from utils import sample_mask

def get_train_data(dataset_name,relation_select,seed):
    if dataset_name=='MGTAB':
        dataset = MGTAB('../../Dataset/MGTAB')
    elif dataset_name=='MGTAB-large':
        dataset = MGTABlarge('../../Dataset/MGTAB')

    data = dataset[0]
    data.y = data.y2

    sample_number = len(data.y)
    shuffled_idx = shuffle(np.array(range(sample_number)), random_state=seed)
    train_idx = torch.from_numpy(shuffled_idx[:int(0.07 * sample_number)])
    val_idx = torch.from_numpy(shuffled_idx[int(0.7 * sample_number):int(0.9 * sample_number)])
    test_idx = torch.from_numpy(shuffled_idx[int(0.9 * sample_number):])

    embedding_size = data.x.shape[1]
    relation_num = len(relation_select)
    index_select_list = (data.edge_type == 100)

    relation_dict = {
        0: 'followers',
        1: 'friends',
        2: 'mention',
        3: 'reply',
        4: 'quoted',
        5: 'url',
        6: 'hashtag'
    }

    print('relation used:', end=' ')
    for features_index in relation_select:
        index_select_list = index_select_list + (features_index == data.edge_type)
        print('{}'.format(relation_dict[features_index]), end='  ')
    print('\n')
    edge_index = data.edge_index[:, index_select_list]
    edge_type = data.edge_type[index_select_list]
    pre_trained_test_idx = torch.cat((train_idx, val_idx, test_idx), dim=0)

    return Data(edge_index=edge_index,
                edge_type=edge_type,
                y=data.y,
                x=data.x,
                train_idx=train_idx,
                val_idx=val_idx,
                test_idx=test_idx,
                pre_trained_test_idx=pre_trained_test_idx,
                num_nodes=sample_number)


def get_train_data_pretrained(dataset_name,relation_select,seed):
    if dataset_name=='MGTAB':
        dataset = MGTAB('./Dataset/MGTAB')
        pretrained_results = torch.load(osp.join('./Dataset/MGTAB/pretrained_embedding'+str(seed)+'.pt')).contiguous()
    elif dataset_name=='MGTAB-large':
        dataset = MGTABlarge('./Dataset/MGTAB-large')
        pretrained_results = torch.load(osp.join('./Dataset/MGTAB/pretrained_embedding'+str(seed)+'.pt')).contiguous()

    data = dataset[0]
    data.y = data.y2

    sample_number = len(data.y)
    shuffled_idx = shuffle(np.array(range(sample_number)), random_state=seed)
    train_idx = torch.from_numpy(shuffled_idx[:int(0.7 * sample_number)])
    val_idx = torch.from_numpy(shuffled_idx[int(0.7 * sample_number):int(0.9 * sample_number)])
    test_idx = torch.from_numpy(shuffled_idx[int(0.9 * sample_number):])



    embedding_size = data.x.shape[1]
    relation_num = len(relation_select)
    index_select_list = (data.edge_type == 100)

    relation_dict = {
        0: 'followers',
        1: 'friends',
        2: 'mention',
        3: 'reply',
        4: 'quoted',
        5: 'url',
        6: 'hashtag'
    }

    print('relation used:', end=' ')
    for features_index in relation_select:
        index_select_list = index_select_list + (features_index == data.edge_type)
        print('{}'.format(relation_dict[features_index]), end='  ')
    print('\n')
    edge_index = data.edge_index[:, index_select_list]
    edge_type = data.edge_type[index_select_list]
    pre_trained_test_idx = torch.cat((train_idx, val_idx, test_idx), dim=0)

    return Data(edge_index=edge_index,
                edge_type=edge_type,
                y=data.y,
                x=data.x,
                train_idx=train_idx,
                val_idx=val_idx,
                test_idx=test_idx,
                pretrained_results=pretrained_results,
                num_nodes=sample_number)


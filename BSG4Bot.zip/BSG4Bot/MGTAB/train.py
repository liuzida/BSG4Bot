import os
import gc
import numba
from argparse import ArgumentParser
from utils import null_metrics, calc_metrics, is_better
import torch
from dataset import get_train_data_pretrained
from ppr_graph import MyPPRGraphDataset,create_ppr_subgraph
from torch_geometric.loader import NeighborLoader
from torch_geometric.data import DataLoader,Data
from tqdm import tqdm
import torch.nn as nn
import random
import numpy as np
import ppr
import time
from  model import HeteroBotGCN,MLP,GCN,GAT,BotRGCN,SAGE

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
parser = ArgumentParser()
parser.add_argument('--dataset', type=str, default='MGTAB')
parser.add_argument('--visible', type=bool, default=True)
parser.add_argument('--hidden_dim', type=int, default=128)
parser.add_argument('--max_epoch', type=int, default=200)
parser.add_argument('--batch_size', type=int, default=128)
parser.add_argument('--no_up', type=int, default=50)
parser.add_argument('--lr', type=float, default=1e-3)
parser.add_argument('--weight_decay', type=float, default=1e-5)
parser.add_argument('--dropout', type=float, default=0.3)
parser.add_argument('--alpha', type=float, default=0.85)# PPR teleport probability
parser.add_argument('--eps', type=float, default=1e-4 )# Stopping threshold for ACL's ApproximatePR
parser.add_argument('--topk', type=int, default=64)# Number of PPR neighbors for each node
parser.add_argument('--ppr_normalization', type=str, default='row')# Adjacency matrix normalization for weighting neighbors
parser.add_argument('--relation_select', type=int, default=[0,1], nargs='+', help='selection of relations in the graph (0-6)')
args = parser.parse_args()

dataset_name = args.dataset
visible = args.visible
hidden_dim = args.hidden_dim
dropout = args.dropout
lr = args.lr
weight_decay = args.weight_decay
max_epoch = args.max_epoch
batch_size = args.batch_size
no_up = args.no_up
alpha=args.alpha
eps=args.eps
topk=args.topk
ppr_normalization=args.ppr_normalization
relation_num = len(args.relation_select)
assert dataset_name in ['MGTAB', 'MGTAB-large']



def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    random.seed(seed)
    print('set seed for random numpy and torch')

def forward_one_epoch(epoch, model, optimizer, loss_fn, train_loader, val_loader):
    model.train()
    all_label = []
    all_pred = []
    ave_loss = 0.0
    cnt = 0.0
    count = 0
    for batch in train_loader:

        optimizer.zero_grad()

        n_batch = len(batch.y)
        batch_mask=batch.x
        batch.features = data.x[batch_mask]
        batch = batch.to(device)

        out = model(batch)

        label = batch.y[:n_batch]
        out = out[:n_batch]
        all_label += label.data
        all_pred += out
        loss = loss_fn(out, label)
        ave_loss += loss.item() * n_batch
        cnt += n_batch
        loss.backward()
        optimizer.step()
        count = count +1
    ave_loss /= cnt
    all_label = torch.stack(all_label)
    all_pred = torch.stack(all_pred)
    metrics, plog = calc_metrics(all_label, all_pred)
    plog = 'Epoch-{} train loss: {:.6}'.format(epoch, ave_loss) + plog
    if visible:
        print(plog)

    val_metrics = validation(epoch, 'validation', model, loss_fn, val_loader)
    return val_metrics


@torch.no_grad()
def validation(epoch, name, model, loss_fn, loader,pretrained=False):
    model.eval()
    all_label = []
    all_pred = []
    ave_loss = 0.0
    cnt = 0.0
    pretrained_embeddings = []
    for batch in loader:

        n_batch = len(batch.y)
        batch_mask = batch.x
        batch.features = data.x[batch_mask]
        batch = batch.to(device)

        out = model(batch)
        if pretrained==True:
            pretrained_embeddings.append(out.cpu())

        label = batch.y[:n_batch]
        out = out[:n_batch]
        all_label += label.data
        all_pred += out
        loss = loss_fn(out, label)
        ave_loss += loss.item() * n_batch
        cnt += n_batch
    ave_loss /= cnt
    all_label = torch.stack(all_label)
    all_pred = torch.stack(all_pred)
    metrics, plog = calc_metrics(all_label, all_pred)
    plog = 'Epoch-{} {} loss: {:.6}'.format(epoch, name, ave_loss) + plog
    if visible:
        print(plog)
    if pretrained == True:
        return metrics,pretrained_embeddings
    else:
        return metrics

def train(seed,mode):

    train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_set, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_set, batch_size=batch_size, shuffle=False)

    if mode=='HeteroBotGCN':
        model = HeteroBotGCN(hidden_dim=hidden_dim,
                             dropout=dropout,
                             num_prop_size=10,
                             cat_prop_size=10,  # ,
                             num_relations=relation_num).to(device)

    elif mode == 'GCN':
        model = GCN(embedding_size, hidden_dim, 2, relation_num, args.dropout).to(device)
    elif mode == 'GAT':
        model = GAT(embedding_size, hidden_dim, 2, relation_num, args.dropout).to(device)
    elif mode == 'GraphSage':
        model = SAGE(embedding_size, hidden_dim, 2, relation_num, args.dropout).to(device)
    elif mode == 'BotRGCN':
        model = BotRGCN(embedding_size, hidden_dim, 2, relation_num, args.dropout).to(device)


    best_val_metrics = null_metrics()
    best_state_dict = None
    loss_fn = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    pbar = tqdm(range(max_epoch), ncols=0)
    cnt = 0

    for epoch in pbar:

        val_metrics = forward_one_epoch(epoch, model, optimizer, loss_fn, train_loader, val_loader)
        print(val_metrics)
        if is_better(val_metrics, best_val_metrics):
            best_val_metrics = val_metrics
            best_state_dict = model.state_dict()
            cnt = 0
        else:
            cnt += 1
        pbar.set_postfix_str('val acc {} no up cnt {}'.format(val_metrics['acc'], cnt))
        if cnt == no_up:
            break


    model.load_state_dict(best_state_dict)

    test_metrics = validation(max_epoch, 'test', model, loss_fn, test_loader)

    torch.save(best_state_dict, 'saved_model/{}_{}_{}.pt'.format(dataset_name,mode,'user'+str(seed)))
    with open('result/' + dataset_name+mode+str(seed), 'w') as file:
        for key, value in test_metrics.items():
            print(key, value, file=file)



if __name__ == '__main__':
    mode = ['GCN', 'GAT', 'GraphSage', 'BotRGCN']
    for model_name in mode:


        for i in range(1):
            set_seed(i)

            data = get_train_data_pretrained(dataset_name,args.relation_select,i)
            embedding_size=data.x.shape[1]
            start = time.time()
            nodes=torch.cat((data.train_idx, data.val_idx, data.test_idx), dim=0)
            train_ppr_matrix = ppr.topk_ppr_matrix(data, alpha, eps, nodes, topk,
                                             normalization=ppr_normalization, directed=False)
            train_set = MyPPRGraphDataset(root=None,
                                          entire_graph=data,
                                          ppr_matrix=train_ppr_matrix,
                                          node_idx=data.train_idx)  
            time_preprocessing = time.time() - start
            torch.save(train_set, 'saved_graph/train_{}.pt'.format(i))
            print(f"train set subgraph extracted time: {time_preprocessing:.2f}s")
            
            start = time.time()
            val_ppr_matrix = ppr.topk_ppr_matrix(data, alpha, eps, data.val_idx, topk,
                                                   normalization=ppr_normalization, directed=False)
            val_set = MyPPRGraphDataset(root=None,
                                        entire_graph=data,
                                        ppr_matrix=train_ppr_matrix,
                                        node_idx=data.val_idx)
            time_preprocessing = time.time() - start
            torch.save(val_set, 'saved_graph/val_{}.pt'.format(i))
            print(f"val_set subgraph extracted time: {time_preprocessing:.2f}s")
            
            start = time.time()
            test_ppr_matrix = ppr.topk_ppr_matrix(data, alpha, eps, data.test_idx, topk,
                                                   normalization=ppr_normalization, directed=False)
            test_set = MyPPRGraphDataset(root=None,
                                         entire_graph=data,
                                         ppr_matrix=train_ppr_matrix,
                                         node_idx=data.test_idx)
            torch.save(test_set, 'saved_graph/test_{}.pt'.format(i))
            time_preprocessing = time.time() - start
            print(f"test_set subgraph extracted time: {time_preprocessing:.2f}s")

            train(i,model_name)

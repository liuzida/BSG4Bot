import torch.nn as nn
import torch
from torch_geometric.nn.conv.gat_conv import GATConv
from torch_geometric.nn.conv.gcn_conv import GCNConv
from torch_geometric.nn.conv.rgcn_conv import RGCNConv
from torch_geometric.nn.conv.sage_conv import SAGEConv
import math
from torch_geometric.nn.conv.rgat_conv import RGATConv
import torch.nn.functional as F


class SemanticAttentionLayer(nn.Module):
    def __init__(self, in_size, hidden_size, num_relations):
        super(SemanticAttentionLayer, self).__init__()
        self.in_size = in_size
        self.hidden_size = hidden_size
        self.num_relations = num_relations
        self.W = nn.Parameter(torch.Tensor(in_size, hidden_size))
        self.b = nn.Parameter(torch.Tensor(hidden_size))
        self.q = nn.Parameter(torch.Tensor(hidden_size, 1))
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.W.size(1))
        self.W.data.uniform_(-stdv, stdv)
        self.b.data.uniform_(-stdv, stdv)
        self.q.data.uniform_(-stdv, stdv)

    def forward(self, h):
        """
        h: Concatenated embeddings from different relations [num_relations, num_nodes, in_size]
        """
        Wh = torch.tanh(torch.matmul(h, self.W) + self.b)  # [num_relations, num_nodes, hidden_size]
        s = torch.matmul(Wh, self.q)  # [num_relations, num_nodes, 1]
        s = s.squeeze(2)  # [num_relations, num_nodes]
        weights = F.softmax(s, dim=0)  # Softmax over relations [num_relations, num_nodes]
        return weights

class HeteroBotGCN(nn.Module):
    def __init__(self, hidden_dim, des_size=768, tweet_size=768, num_prop_size=5, cat_prop_size=3, dropout=0.3,num_relations=2,num_layers=2):
        super(HeteroBotGCN, self).__init__()

        self.linear_relu_tweet = torch.nn.Sequential(
            torch.nn.Linear(tweet_size, int(hidden_dim * 3 / 4)),
            torch.nn.LeakyReLU()
        )
        self.linear_relu_num_prop = torch.nn.Sequential(
            torch.nn.Linear(num_prop_size, int(hidden_dim / 8)),
            torch.nn.LeakyReLU()
        )
        self.linear_relu_cat_prop = torch.nn.Sequential(
            torch.nn.Linear(cat_prop_size, int(hidden_dim / 8)),
            torch.nn.LeakyReLU()
        )

        self.linear_relu_input = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.LeakyReLU()
        )
        self.linear_relu_output1 = nn.Sequential(
            nn.Linear(hidden_dim*3, hidden_dim),
            nn.LeakyReLU()
        )
        self.linear_output2 = nn.Linear(hidden_dim, 2)
        self.num_layers = num_layers
        self.gcn_layers = nn.ModuleList()
        for _ in range(num_relations):
            self.gcn_layers.append(nn.ModuleList([GCNConv(hidden_dim, hidden_dim) for _ in range(num_layers)]))
        self.semantic_attention = SemanticAttentionLayer(hidden_dim * (num_layers + 1), hidden_dim // 2, num_relations)
        self.dropout = nn.Dropout(p=dropout)




    def forward(self, data):

        x, edge_index, edge_type, batch = data.features, data.edge_index, data.edge_type, data.batch
        t = self.linear_relu_tweet(x[:, 20:788].to(torch.float32))
        n = self.linear_relu_num_prop(x[:, [3, 5, 6, 7, 9, 10, 11, 12, 13, 14]].to(torch.float32))
        b = self.linear_relu_cat_prop(x[:, [0, 1, 2, 4, 8, 15, 16, 17, 18, 19]].to(torch.float32))
        x = torch.cat((t, n, b), dim=1)


        x = self.linear_relu_input(x)

        all_relation_embeddings = []
        for relation_index, gcn_layer_group in enumerate(self.gcn_layers):
            relation_embeddings = [x]  # Include input features as the 0-th layer output
            mask = edge_type == relation_index
            edge_index_i = edge_index[:, mask]
            for gcn_layer in gcn_layer_group:
                x_i = gcn_layer(relation_embeddings[-1], edge_index_i)  # Apply GCN layer
                x_i = self.dropout(x_i)
                relation_embeddings.append(x_i)  # Append output of this layer
            # Concatenate outputs of all layers for this relation
            concatenated_embeddings = torch.cat(relation_embeddings, dim=1)
            all_relation_embeddings.append(concatenated_embeddings.unsqueeze(0))

        # Now, all_relation_embeddings is a list of tensors with shape [1, num_nodes, hidden_dim * (num_layers + 1)]
        relation_embeddings = torch.cat(all_relation_embeddings,
                                        dim=0)  # [num_relations, num_nodes, hidden_dim * (num_layers + 1)]

        # Semantic attention and final processing remain similar
        weights = self.semantic_attention(relation_embeddings)
        x_final = torch.einsum('rni,rn->ni', relation_embeddings, weights)


        x_center_node = x_final[data.x_center_features == True]

        x = self.linear_relu_output1(x_center_node)

        x = self.linear_output2(x)


        return x


class BotRGCN(nn.Module):
    def __init__(self, embedding_dimension=16, hidden_dimension=128, out_dim=3, relation_num=2, dropout=0.3):
        super(BotRGCN, self).__init__()
        self.dropout = dropout

        self.linear_relu_tweet=nn.Sequential(
            nn.Linear(768, int(hidden_dimension*3/4)),
            nn.LeakyReLU()
        )
        self.linear_relu_num_prop=nn.Sequential(
            nn.Linear(10, int(hidden_dimension/8)),
            nn.LeakyReLU()
        )
        self.linear_relu_cat_prop=nn.Sequential(
            nn.Linear(10, int(hidden_dimension/8)),
            nn.LeakyReLU()
        )

        self.linear_relu_input = nn.Sequential(
            nn.Linear(hidden_dimension, hidden_dimension),
            nn.LeakyReLU()
        )

        self.rgcn = RGCNConv(hidden_dimension, hidden_dimension, num_relations=relation_num)

        self.linear_relu_output1 = nn.Sequential(
            nn.Linear(hidden_dimension, hidden_dimension),
            nn.LeakyReLU()
        )
        self.linear_output2 = nn.Linear(hidden_dimension*3, out_dim)

    def forward(self, data):

        x, edge_index, edge_type, batch = data.features, data.edge_index, data.edge_type, data.batch
        t = self.linear_relu_tweet(x[:, 20:788].to(torch.float32))
        n = self.linear_relu_num_prop(x[:, [3, 5, 6, 7, 9, 10, 11, 12, 13, 14]].to(torch.float32))
        b = self.linear_relu_cat_prop(x[:, [0, 1, 2, 4, 8, 15, 16, 17, 18, 19]].to(torch.float32))
        x = torch.cat((t, n, b), dim=1)

        x1 = self.rgcn(x, edge_index, edge_type)
        x2 = F.dropout(x1, p=self.dropout, training=self.training)
        x2 = self.rgcn(x2, edge_index, edge_type)
        # x = self.linear_relu_output1(x)
        x = torch.cat((x, x1, x2), dim=1)
        x = self.linear_output2(x)

        x_center_node = x[data.x_center_features == True]

        return x_center_node



class RGCN(nn.Module):
    def __init__(self, embedding_dimension=16, hidden_dimension=128, out_dim=3, relation_num=2, dropout=0.3):
        super(RGCN, self).__init__()
        self.dropout = dropout
        self.linear_relu_tweet = nn.Sequential(
            nn.Linear(768, int(hidden_dimension * 3 / 4)),
            nn.LeakyReLU()
        )
        self.linear_relu_num_prop = nn.Sequential(
            nn.Linear(10, int(hidden_dimension / 8)),
            nn.LeakyReLU()
        )
        self.linear_relu_cat_prop = nn.Sequential(
            nn.Linear(10, int(hidden_dimension / 8)),
            nn.LeakyReLU()
        )

        self.linear_relu_input = nn.Sequential(
            nn.Linear(hidden_dimension, hidden_dimension),
            nn.LeakyReLU()
        )
        self.rgcn1 = RGCNConv(hidden_dimension, hidden_dimension, num_relations=relation_num)
        self.rgcn2 = RGCNConv(hidden_dimension, hidden_dimension, num_relations=relation_num)

        self.linear_relu_output1 = nn.Sequential(
            nn.Linear(hidden_dimension, hidden_dimension),
            nn.LeakyReLU()
        )
        self.linear_output2 = nn.Linear(hidden_dimension, out_dim)

    def forward(self, data):
        x, edge_index, edge_type, batch = data.features, data.edge_index, data.edge_type, data.batch
        t = self.linear_relu_tweet(x[:, 20:788].to(torch.float32))
        n = self.linear_relu_num_prop(x[:, [3, 5, 6, 7, 9, 10, 11, 12, 13, 14]].to(torch.float32))
        b = self.linear_relu_cat_prop(x[:, [0, 1, 2, 4, 8, 15, 16, 17, 18, 19]].to(torch.float32))
        x = torch.cat((t, n, b), dim=1)

        x = self.linear_relu_input(x.to(torch.float32))
        x = self.rgcn1(x, edge_index, edge_type)
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.rgcn1(x, edge_index, edge_type)
        # x = self.linear_relu_output1(x)
        x = self.linear_output2(x)

        x_center_node = x[data.x_center_features == True]

        return x_center_node



class GAT(nn.Module):
    def __init__(self, embedding_dimension=16, hidden_dimension=128, out_dim=3, relation_num=2, dropout=0.3):
        super(GAT, self).__init__()
        self.dropout = dropout
        self.linear_relu_tweet = nn.Sequential(
            nn.Linear(768, int(hidden_dimension * 3 / 4)),
            nn.LeakyReLU()
        )
        self.linear_relu_num_prop = nn.Sequential(
            nn.Linear(10, int(hidden_dimension / 8)),
            nn.LeakyReLU()
        )
        self.linear_relu_cat_prop = nn.Sequential(
            nn.Linear(10, int(hidden_dimension / 8)),
            nn.LeakyReLU()
        )

        self.linear_relu_input = nn.Sequential(
            nn.Linear(hidden_dimension, hidden_dimension),
            nn.LeakyReLU()
        )

        self.gat1 = GATConv(hidden_dimension, int(hidden_dimension / 8), heads=8)
        self.gat2 = GATConv(hidden_dimension, hidden_dimension)

        self.linear_relu_output1 = nn.Sequential(
            nn.Linear(hidden_dimension, hidden_dimension),
            nn.LeakyReLU()
        )
        self.linear_output2 = nn.Linear(hidden_dimension, out_dim)

    def forward(self, data):
        x, edge_index, edge_type, batch = data.features, data.edge_index, data.edge_type, data.batch
        t = self.linear_relu_tweet(x[:, 20:788].to(torch.float32))
        n = self.linear_relu_num_prop(x[:, [3, 5, 6, 7, 9, 10, 11, 12, 13, 14]].to(torch.float32))
        b = self.linear_relu_cat_prop(x[:, [0, 1, 2, 4, 8, 15, 16, 17, 18, 19]].to(torch.float32))
        x = torch.cat((t, n, b), dim=1)

        x = self.linear_relu_input(x.to(torch.float32))
        x = self.gat1(x, edge_index)
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.gat2(x, edge_index)
        # x = self.linear_relu_output1(x)
        x = self.linear_output2(x)
        x_center_node = x[data.x_center_features == True]

        return x_center_node



class GCN(nn.Module):
    def __init__(self, embedding_dimension=16, hidden_dimension=128, out_dim=3, relation_num=2, dropout=0.3):
        super(GCN, self).__init__()
        self.dropout = dropout
        self.linear_relu_tweet = nn.Sequential(
            nn.Linear(768, int(hidden_dimension * 3 / 4)),
            nn.LeakyReLU()
        )
        self.linear_relu_num_prop = nn.Sequential(
            nn.Linear(10, int(hidden_dimension / 8)),
            nn.LeakyReLU()
        )
        self.linear_relu_cat_prop = nn.Sequential(
            nn.Linear(10, int(hidden_dimension / 8)),
            nn.LeakyReLU()
        )

        self.linear_relu_input = nn.Sequential(
            nn.Linear(hidden_dimension, hidden_dimension),
            nn.LeakyReLU()
        )

        self.gcn1 = GCNConv(hidden_dimension, hidden_dimension)
        self.gcn2 = GCNConv(hidden_dimension, hidden_dimension)

        self.linear_relu_output1 = nn.Sequential(
            nn.Linear(hidden_dimension, hidden_dimension),
            nn.LeakyReLU()
        )
        self.linear_output2 = nn.Linear(hidden_dimension, out_dim)

    def forward(self, data):
        x, edge_index, edge_type, batch = data.features, data.edge_index, data.edge_type, data.batch
        t = self.linear_relu_tweet(x[:, 20:788].to(torch.float32))
        n = self.linear_relu_num_prop(x[:, [3, 5, 6, 7, 9, 10, 11, 12, 13, 14]].to(torch.float32))
        b = self.linear_relu_cat_prop(x[:, [0, 1, 2, 4, 8, 15, 16, 17, 18, 19]].to(torch.float32))
        x = torch.cat((t, n, b), dim=1)
        x = self.linear_relu_input(x.to(torch.float32))
        x = self.gcn1(x, edge_index)
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.gcn2(x, edge_index)
        # x = self.linear_relu_output1(x)
        x = self.linear_output2(x)

        x_center_node = x[data.x_center_features == True]

        return x_center_node


class SAGE(nn.Module):
    def __init__(self, embedding_dimension=16, hidden_dimension=128, out_dim=3, relation_num=2, dropout=0.3):
        super(SAGE, self).__init__()
        self.dropout = dropout
        self.linear_relu_tweet = nn.Sequential(
            nn.Linear(768, int(hidden_dimension * 3 / 4)),
            nn.LeakyReLU()
        )
        self.linear_relu_num_prop = nn.Sequential(
            nn.Linear(10, int(hidden_dimension / 8)),
            nn.LeakyReLU()
        )
        self.linear_relu_cat_prop = nn.Sequential(
            nn.Linear(10, int(hidden_dimension / 8)),
            nn.LeakyReLU()
        )

        self.linear_relu_input = nn.Sequential(
            nn.Linear(hidden_dimension, hidden_dimension),
            nn.LeakyReLU()
        )

        self.sage1 = SAGEConv(hidden_dimension, hidden_dimension)
        self.sage2 = SAGEConv(hidden_dimension, hidden_dimension)

        self.linear_relu_output1 = nn.Sequential(
            nn.Linear(hidden_dimension, hidden_dimension),
            nn.LeakyReLU()
        )
        self.linear_output2 = nn.Linear(hidden_dimension, out_dim)

    def forward(self, data):
        x, edge_index, edge_type, batch = data.features, data.edge_index, data.edge_type, data.batch
        t = self.linear_relu_tweet(x[:, 20:788].to(torch.float32))
        n = self.linear_relu_num_prop(x[:, [3, 5, 6, 7, 9, 10, 11, 12, 13, 14]].to(torch.float32))
        b = self.linear_relu_cat_prop(x[:, [0, 1, 2, 4, 8, 15, 16, 17, 18, 19]].to(torch.float32))
        x = torch.cat((t, n, b), dim=1)
        x = self.linear_relu_input(x.to(torch.float32))
        x = self.sage1(x, edge_index)
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.sage2(x, edge_index)
        # x = self.linear_relu_output1(x)
        x = self.linear_output2(x)

        x_center_node = x[data.x_center_features == True]

        return x_center_node




class MLP(nn.Module):
    def __init__(self, hidden_dim,
                 tweet_size=768,
                 num_prop_size=10,
                 cat_prop_size=10,
                 dropout=0.3,
                 num_relations=2):
        # print("21")
        super(MLP, self).__init__()

        self.linear_relu_tweet = torch.nn.Sequential(
            torch.nn.Linear(tweet_size, int(hidden_dim * 3 / 4)),
            torch.nn.LeakyReLU()
        )
        self.linear_relu_num_prop = torch.nn.Sequential(
            torch.nn.Linear(num_prop_size, int(hidden_dim / 8)),
            torch.nn.LeakyReLU()
        )
        self.linear_relu_cat_prop = torch.nn.Sequential(
            torch.nn.Linear(cat_prop_size, int(hidden_dim / 8)),
            torch.nn.LeakyReLU()
        )

        self.linear_relu_label_prop = torch.nn.Sequential(
            torch.nn.Linear(2, int(hidden_dim / 8)),
            torch.nn.LeakyReLU()
        )

        self.linear_relu_input = torch.nn.Sequential(
            torch.nn.Linear(hidden_dim , hidden_dim),
            torch.nn.LeakyReLU()
        )

        self.linear_relu_output1 = torch.nn.Sequential(
            torch.nn.Linear(hidden_dim, hidden_dim),
            torch.nn.LeakyReLU()
        )
        self.linear_relu_output2 = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 4),
            nn.LeakyReLU()
        )
        self.linear_output2 = torch.nn.Linear(hidden_dim // 4, 2)
        self.dropout = torch.nn.Dropout(p=dropout)

    def forward(self, data):
        x, edge_index, edge_type, batch = data.x, data.edge_index, data.edge_type, data.batch
        t = self.linear_relu_tweet(x[:, 20:788].to(torch.float32))
        n = self.linear_relu_num_prop(x[:, [3, 5, 6, 7, 9, 10, 11, 12, 13, 14]].to(torch.float32))
        b = self.linear_relu_cat_prop(x[:, [0, 1, 2, 4, 8, 15, 16, 17, 18, 19]].to(torch.float32))
        x = torch.cat((t, n, b), dim=1)

        x = self.linear_relu_input(x)
        x = self.linear_relu_output1(x)
        x = self.dropout(x)
        x1 = self.linear_relu_output2(x)
        x = self.linear_output2(x1)

        return x,x1
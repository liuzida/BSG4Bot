import time
import networkx as nx
import numba
from numba import jit, prange, njit
import numpy as np
import torch
import scipy.sparse as sp
from sklearn.metrics.pairwise import cosine_similarity
from scipy.sparse import find
from collections import defaultdict
from tqdm import tqdm
from typing import List


def topk_ppr_matrix(data, alpha, eps, node_idx, topk, normalization='row',directed=True):

    print(directed)

    num_nodes = len(data.y)

    adj_matrix_all = get_sparse_matrices(data.y,data.edge_type,data.edge_index,directed)

    """Create a sparse matrix where each node has up to the topk PPR neighbors and their weights."""
    print('adj_matrix done')

    topk_matrix = {}
    for edge_type, adj_matrix in adj_matrix_all.items():



        ppr_nghbs, ppr_wgts = ppr_topk(adj_matrix, alpha, eps, node_idx.numpy(), topk)


        if normalization == 'sym':
            deg = adj_matrix.sum(1).A1
            deg_sqrt = np.sqrt(np.maximum(deg, 1e-12))
            deg_inv_sqrt = 1. / deg_sqrt

            row, col = topk_matrix.nonzero()
            topk_matrix.data = deg_sqrt[node_idx[row]] * topk_matrix.data * deg_inv_sqrt[col]

        elif normalization == 'col':
            deg = adj_matrix.sum(1).A1
            deg_inv = 1. / np.maximum(deg, 1e-12)
            row, col = topk_matrix.nonzero()
            topk_matrix.data = deg[node_idx[row]] * topk_matrix.data * deg_inv[col]

        elif normalization == 'row':
            pass
        else:
            raise ValueError(f"Unknown PPR normalization: {normalization}")

        node_features = data.pretrained_results.detach().numpy()

        y = data.y.detach().numpy()

        node_neigbhors = get_biased_ppr_matrix_weig(node_features, y, node_idx.numpy(), ppr_nghbs, ppr_wgts, topk,
                                                    num_nodes)  

        topk_matrix[edge_type] = node_neigbhors

    return topk_matrix, adj_matrix_all



def topk_ppr_matrix_ts(data, alpha, eps, node_idx, topk, normalization='row',directed=True):



    adj_matrix_all = get_sparse_matrices(data.edge_type,data.edge_index,directed)

    """Create a sparse matrix where each node has up to the topk PPR neighbors and their weights."""
    num_nodes = len(data.y)

    topk_matrix = {}
    for edge_type, adj_matrix in adj_matrix_all.items():


        start = time.time()
        ppr_nghbs, ppr_wgts = ppr_topk(adj_matrix, alpha, eps, node_idx.numpy(), topk) 

        time_preprocessing = time.time() - start
        print(f"Finish Computing PPR: {time_preprocessing:.2f}s")
        if normalization == 'sym':
            # Assume undirected (symmetric) adjacency matrix
            deg = adj_matrix.sum(1).A1
            deg_sqrt = np.sqrt(np.maximum(deg, 1e-12))
            deg_inv_sqrt = 1. / deg_sqrt

            row, col = topk_matrix.nonzero()
            topk_matrix.data = deg_sqrt[idx[row]] * topk_matrix.data * deg_inv_sqrt[col]

        elif normalization == 'col':
            deg = adj_matrix.sum(1).A1
            deg_inv = 1. / np.maximum(deg, 1e-12)

            row, col = topk_matrix.nonzero()
            topk_matrix.data = deg[idx[row]] * topk_matrix.data * deg_inv[col]
        elif normalization == 'row':
            pass
        else:
            raise ValueError(f"Unknown PPR normalization: {normalization}")

        node_features = data.pretrained_results.detach().numpy()

        y = data.y.detach().numpy()

        node_neigbhors = get_biased_ppr_matrix_weig(node_features, y,  node_idx.numpy(), ppr_nghbs, ppr_wgts, topk, num_nodes)

        topk_matrix[edge_type] = node_neigbhors



    return topk_matrix




@numba.njit(cache=True)
def normalize_scores(scores):
    min_score = np.min(scores)
    max_score = np.max(scores)
    if max_score > min_score:
        return (scores - min_score) / (max_score - min_score)
    else:
        return scores


@numba.njit(cache=True)
def cosine_similarity_numba(X, Y=None):
    X = np.asarray(X)
    if Y is None:
        Y = X
    else:
        Y = np.asarray(Y)

    if X.shape[1] != Y.shape[1]:
        raise ValueError("Incompatible array sizes for X and Y")

    dot_products = np.dot(X, Y.T)

    norms_X = np.sqrt(np.sum(X ** 2, axis=1))
    norms_Y = np.sqrt(np.sum(Y ** 2, axis=1))

    norms_product = np.outer(norms_X, norms_Y)
    similarity = dot_products / (norms_product + 1e-9)  # 防止0
    return similarity


@numba.njit(cache=False)
def get_biased_ppr_matrix_weig(node_features, y, select_nodes, ppr_nghbs, ppr_wgts, topk, N):

    select_nghbs = [np.zeros(0, dtype=np.int64) ]* (len(select_nodes))

    wrong0, wrong1, correct0, correct1 = 0, 0, 0, 0
    best1 = 0

    for i in prange(len(select_nodes)):

        node_id_in_graph = select_nodes[i].item()

        neighbors = ppr_nghbs[i]
        ppr_values = ppr_wgts[i]



        if len(neighbors) == 0:
            continue

        rootlabel = y[node_id_in_graph]

        if node_id_in_graph in neighbors:
            center_index = np.where(neighbors == node_id_in_graph)[0]
            neighbors = np.delete(neighbors, center_index)
            ppr_values = np.delete(ppr_values, center_index)

        if len(neighbors) == 0:  
            continue
        ppr_values_normalized = normalize_scores(ppr_values)
        center_feature = node_features[i].reshape(1, -1)
        neighbor_features = node_features[neighbors]
        similarities = cosine_similarity_numba(center_feature, neighbor_features).flatten()
        normalized_similarities = normalize_scores(similarities)

        content_weight = 0.2
        scores = normalized_similarities * content_weight + ppr_values_normalized * (1 - content_weight)

        topk_indices = np.argsort(scores)[-topk:]
        select_nghbs[i] = neighbors[topk_indices]



        cnt =0
        for ngb in select_nghbs[i]:
            if rootlabel == y[ngb]:
                cnt = cnt +1

        if rootlabel == 0:
            if cnt / len(select_nghbs[i]) < 0.5:
                wrong0 += 1
            else:
                correct0 += 1

        if rootlabel == 1:
            if cnt / len(select_nghbs[i]) < 0.5:
                wrong1 += 1
            else:
                correct1 += 1

    print(f"Wrong 95: {wrong0} for label 0 ， {wrong1} for label 1， out of total {len(select_nodes)} ")
    print(f"Correct: {correct0} for label 0 ， {correct1} for label 1， out of total {len(select_nodes)} ")
    print((wrong0 + wrong1) / len(select_nodes))

    return select_nghbs


@numba.njit(cache=True, locals={'_val': numba.float32, 'res': numba.float32, 'res_vnode': numba.float32})
def _calc_ppr_node(inode, indptr, indices, deg, alpha, epsilon, N):  # Added N as a parameter to represent the total number of nodes

    alpha_eps = alpha * epsilon
    f32_0 = numba.float32(0)
    p = {inode: f32_0}
    r = {}
    r[inode] = alpha
    q = [inode]

    while len(q) > 0:
        unode = q.pop()

        res = r[unode] if unode in r else f32_0
        if unode in p:
            p[unode] += res
        else:
            p[unode] = res
        r[unode] = f32_0

        for vnode in indices[indptr[unode]:indptr[unode + 1]]:
            if deg[unode] == 0:
                _val = (1 - alpha) * res / max(deg[unode], 1)
            else:
                _val = (1 - alpha) * res / deg[unode]  
            if vnode in r:
                r[vnode] += _val
            else:
                r[vnode] = _val
            res_vnode = r[vnode] if vnode in r else f32_0
            if res_vnode >= alpha_eps * deg[vnode]:
                if vnode not in q:
                    q.append(vnode)

    return list(p.keys()), list(p.values())




@numba.njit(cache=True)
def calc_ppr(indptr, indices, deg, alpha, epsilon, nodes):
    js = []
    vals = []
    for i, node in enumerate(nodes):
        j, val = _calc_ppr_node(node, indptr, indices, deg, alpha, epsilon)
        js.append(j)
        vals.append(val)
    return js, vals


@numba.njit(cache=True)
def get_biased_ppr_matrix_weig_gj(node_features, y, select_nodes, ppr_nghbs, ppr_wgts, topk, N):

    select_nghbs = [np.zeros(0, dtype=np.int64) ]* (len(select_nodes))

    wrongselected = [0, 0]
    correctselected = [0, 0]

    for i in prange(len(select_nodes)):

        node_id_in_graph = select_nodes[i].item()

        neighbors = ppr_nghbs[i]
        ppr_values = ppr_wgts[i]

        if len(neighbors) == 0:
            continue

        if i % 100000 ==0:
            print(i)

        if node_id_in_graph in neighbors:
            center_index = np.where(neighbors == node_id_in_graph)[0]
            neighbors = np.delete(neighbors, center_index)
            ppr_values = np.delete(ppr_values, center_index)

        if len(neighbors) == 0:  
            continue

        min_score = np.min(ppr_values)
        max_score = np.max(ppr_values)
        if max_score > min_score:
            ppr_values_normalized = (ppr_values - min_score) / (max_score - min_score)
        else:
            ppr_values_normalized = ppr_values

        center_feature = node_features[node_id_in_graph].reshape(1, -1)
        norms = (center_feature @ center_feature.T).flatten()

        center_feature /= norms[:, None]

        neighbor_features = node_features[neighbors]
        norms = np.sum(neighbor_features * neighbor_features, axis=1).flatten()
        norms = np.sqrt(norms)
        neighbor_features /= norms[:, None]

        similarities = (neighbor_features @ center_feature.T).flatten()

        min_score = np.min(similarities)
        max_score = np.max(similarities)
        if max_score > min_score:
            normalized_similarities = (similarities - min_score) / (max_score - min_score)
        else:
            normalized_similarities = similarities

        content_weight = 0.85
        scores = normalized_similarities * content_weight + ppr_values_normalized * (1 - content_weight)

        topk_indices = np.argsort(scores)[-topk:]
        select_nghbs[i] = neighbors[topk_indices]

        rootlabel = y[node_id_in_graph]

        cnt =0
        for ngb in select_nghbs[i]:
            if rootlabel == y[ngb]:
                cnt = cnt +1

        if cnt/len(select_nghbs[i])<0.5:
            wrongselected[rootlabel] = wrongselected[rootlabel] +1
        else:
            correctselected[rootlabel] = correctselected[rootlabel] + 1

    print(f"{wrongselected[0] } for label 0 ， {wrongselected[1]} for label 1， out of total {len(select_nodes)} ")

    return select_nghbs



@numba.njit(cache=False, parallel=True)
def calc_ppr_topk_parallel(indptr, indices, deg, alpha, epsilon, nodes, topk, N):
    js = [np.zeros(0, dtype=np.int64)] * len(nodes)
    vals = [np.zeros(0, dtype=np.float32)] * len(nodes)

    for i in numba.prange(len(nodes)):
        j, val = _calc_ppr_node(nodes[i], indptr, indices, deg, alpha, epsilon,N)
        j_np, val_np = np.array(j), np.array(val)
        idx_topk = np.argsort(val_np)[-val_np.shape[0]:]
        js[i] = j_np[idx_topk]
        vals[i] = val_np[idx_topk]


    return js, vals

@numba.njit(cache=True, parallel=True)
def calc_ppr_topk_parallel_gj(indptr, indices, deg, alpha, epsilon, nodes, topk, N):
    js = [np.zeros(0, dtype=np.int64)] *  len(nodes)
    vals = [np.zeros(0, dtype=np.float32)] * len(nodes)

    for i in numba.prange(len(nodes)):
        j, val = _calc_ppr_node(nodes[i], indptr, indices, deg, alpha, epsilon,N)
        j_np, val_np = np.array(j), np.array(val)
        idx_topk = np.argsort(val_np)[-val_np.shape[0]:]
        js[i] = j_np[idx_topk]
        vals[i] = val_np[idx_topk]


    return js, vals


def ppr_topk(adj_matrix, alpha, epsilon, nodes, topk):
    """Calculate the PPR matrix approximately using Anderson."""
    N = max(adj_matrix.shape[0],adj_matrix.shape[1])
    out_degree = np.sum(adj_matrix > 0, axis=1).A1

    nnodes = max(adj_matrix.shape[0],adj_matrix.shape[1])

    neighbors, weights = calc_ppr_topk_parallel(adj_matrix.indptr, adj_matrix.indices, out_degree,
                                                numba.float32(alpha), numba.float32(epsilon), nodes, topk,N)
    weights = [w / np.sum(w) for w in weights]

    return neighbors, weights


def construct_sparse(neighbors, weights, shape,alpha):
    i = np.repeat(np.arange(len(neighbors)), np.fromiter(map(len, neighbors), dtype=int))
    j = np.concatenate(neighbors)
    data = np.concatenate(weights)
    return sp.coo_matrix((data, (i, j)), shape)


def get_sparse_matrices(num, edge_type, edge_index,directed):

    if not isinstance(edge_index, np.ndarray):
        edge_index = edge_index.numpy()
    if not isinstance(edge_type, np.ndarray):
        edge_type = edge_type.numpy()

    num_node=len(num)
    num_edge_types = np.max(edge_type) + 1

    subgraph_matrices_csr= {}

    for edge_type_id in range(num_edge_types):
        type_mask = edge_type == edge_type_id
        subgraph_edges = edge_index[:, type_mask]


        if directed:
            matrix_csr = sp.csr_matrix((np.ones(subgraph_edges.shape[1]), (subgraph_edges[0], subgraph_edges[1])),shape=[num_node,num_node])
        else:
            undirected_edges = np.hstack([subgraph_edges, subgraph_edges[[1, 0]]])
            matrix_csr = sp.csr_matrix((np.ones(undirected_edges.shape[1]), (undirected_edges[0], undirected_edges[1])),shape=[num_node,num_node])
        subgraph_matrices_csr[edge_type_id] = matrix_csr


    return subgraph_matrices_csr


def get_biased_ppr_matrix0(data, ppr_matrix, topk):
    node_features = data.pretrained_results.numpy()  
    rows, cols, vals = [], [], []

    for i in range(ppr_matrix.shape[0]):
        neighbors = ppr_matrix[i].nonzero()[1]
        ppr_values = ppr_matrix[i].data

        if len(neighbors) == 0:
            continue

        center_feature = node_features[i].reshape(1, -1)
        neighbor_features = node_features[neighbors]
        similarities = cosine_similarity(center_feature, neighbor_features).flatten()

        normalized_similarities = (similarities + 1) / 2

        scores = normalized_similarities * ppr_values
        topk_indices = np.argsort(scores)[-topk:]
        topk_neighbors = neighbors[topk_indices]
        topk_scores = scores[topk_indices]

        rows.extend([i] * len(topk_neighbors))
        cols.extend(topk_neighbors)
        vals.extend(topk_scores)

    new_sparse_matrix = sp.coo_matrix((vals, (rows, cols)), shape=ppr_matrix.shape)

    return new_sparse_matrix


def get_biased_ppr_matrix_mul(data, ppr_matrix, topk):
    node_features = data.pretrained_results.numpy()
    rows, cols, vals = [], [], []

    for i in range(ppr_matrix.shape[0]):
        neighbors = ppr_matrix[i].nonzero()[1]
        ppr_values = ppr_matrix[i].data

        if len(neighbors) == 0:
            continue

        if i in neighbors:
            center_index = np.where(neighbors == i)[0]
            neighbors = np.delete(neighbors, center_index)
            ppr_values = np.delete(ppr_values, center_index)

        if len(neighbors) == 0:
            continue

        ppr_values_normalized = normalize_scores(ppr_values)

        center_feature = node_features[i].reshape(1, -1)
        neighbor_features = node_features[neighbors]
        similarities = cosine_similarity(center_feature, neighbor_features).flatten()
        normalized_similarities = normalize_scores(similarities)

        final_scores = ppr_values_normalized * normalized_similarities

        topk_indices = np.argsort(final_scores)[-topk:]
        topk_neighbors = neighbors[topk_indices]
        topk_scores = final_scores[topk_indices]

        rows.extend([i] * len(topk_neighbors))
        cols.extend(topk_neighbors)
        vals.extend(topk_scores)

    new_sparse_matrix = sp.coo_matrix((vals, (rows, cols)), shape=ppr_matrix.shape)
    return new_sparse_matrix








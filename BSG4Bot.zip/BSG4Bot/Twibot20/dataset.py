import os

import torch
import os.path as osp
from torch_geometric.data import Data


def get_train_data(dataset_name):
    if dataset_name == 'Twibot-20':
        path = './processed_data_20'
        tweet_embedding = torch.load(osp.join(path, 'tweets_tensor.pt')).contiguous()
    else:
        path = './processed_data'
        tweet_embedding = torch.load(osp.join(path, 'tweets_tensor_new.pt')).contiguous()
    if not osp.exists(path):
        raise KeyError
    labels = torch.load(osp.join(path, 'label.pt'))
    print(len(labels))


    des_embedding = torch.load(osp.join(path, 'des_tensor.pt')).contiguous()

    num_property_embedding = torch.load(osp.join(path, 'num_properties_tensor.pt')).contiguous()
    cat_property_embedding = torch.load(osp.join(path, 'cat_properties_tensor.pt')).contiguous()
    print(des_embedding.shape,tweet_embedding.shape,num_property_embedding.shape,cat_property_embedding.shape)
    edge_index = torch.load(osp.join(path, 'edge_index.pt')).contiguous()
    edge_type = torch.load(osp.join(path, 'edge_type.pt')).contiguous()



    if dataset_name == 'Twibot-20':
        random_values = torch.randint(0, 2, (217754,), dtype=torch.long)
        labels = torch.cat([labels, random_values])

        train_idx = torch.arange(0, 8278)
        val_idx = torch.arange(8278, 8278 + 2365)
        test_idx = torch.arange(8278+2365, 8278 + 2365 + 1183)
        pre_trained_test_idx=torch.arange(0,229580)
    else:

        train_idx = torch.load(osp.join(path, 'train_idx.pt'))
        val_idx = torch.load(osp.join(path, 'val_idx.pt'))
        test_idx = torch.load(osp.join(path, 'test_idx.pt'))
        pre_trained_test_idx=torch.cat((train_idx, val_idx, test_idx), dim=0)

    return Data(edge_index=edge_index,
                edge_type=edge_type,
                y=labels,
                des_embedding=des_embedding,
                tweet_embedding=tweet_embedding,
                num_property_embedding=num_property_embedding,
                cat_property_embedding=cat_property_embedding,
                train_idx=train_idx,
                val_idx=val_idx,
                test_idx=test_idx,
                pre_trained_test_idx=pre_trained_test_idx,
                num_nodes=des_embedding.shape[0])


def get_train_data_pretrained(dataset_name):
    if dataset_name == 'Twibot-20':
        path = './processed_data_20'
        tweet_embedding = torch.load(osp.join(path, 'tweets_tensor.pt')).contiguous()
    else:
        path = './processed_data'
        tweet_embedding = torch.load(osp.join(path, 'tweets_tensor_new.pt')).contiguous()
    if not osp.exists(path):
        raise KeyError
    labels = torch.load(osp.join(path, 'label.pt'))
    print(len(labels))


    des_embedding = torch.load(osp.join(path, 'des_tensor.pt')).contiguous()
    num_property_embedding = torch.load(osp.join(path, 'num_properties_tensor.pt')).contiguous()
    cat_property_embedding = torch.load(osp.join(path, 'cat_properties_tensor.pt')).contiguous()
    pretrained_results=torch.load(osp.join(path, 'pretrained_embedding3.pt')).contiguous()

    edge_index = torch.load(osp.join(path, 'edge_index.pt')).contiguous()
    edge_type = torch.load(osp.join(path, 'edge_type.pt')).contiguous()



    if dataset_name == 'Twibot-20':
        random_values = torch.randint(0, 2, (217754,), dtype=torch.long)
        labels = torch.cat([labels, random_values])
        train_idx = torch.arange(0, 8278)
        val_idx = torch.arange(8278, 8278 + 2365)
        test_idx = torch.arange(8278+2365, 8278 + 2365 + 1183)
    else:

        train_idx = torch.load(osp.join(path, 'train_idx.pt'))
        val_idx = torch.load(osp.join(path, 'val_idx.pt'))
        test_idx = torch.load(osp.join(path, 'test_idx.pt'))

    return Data(edge_index=edge_index,
                edge_type=edge_type,
                y=labels,
                des_embedding=des_embedding,
                tweet_embedding=tweet_embedding,
                num_property_embedding=num_property_embedding,
                cat_property_embedding=cat_property_embedding,
                pretrained_results=pretrained_results,
                train_idx=train_idx,
                val_idx=val_idx,
                test_idx=test_idx,
                num_nodes=des_embedding.shape[0])
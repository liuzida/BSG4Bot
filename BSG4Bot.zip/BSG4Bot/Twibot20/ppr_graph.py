# coding=utf-8
from __future__ import print_function
import numpy as np

from tqdm import tqdm
import os
import networkx as nx
import scipy.sparse as ssp
import torch
import torch.nn.functional as F
from torch_geometric.data import Data, Dataset, InMemoryDataset
import warnings
import dgl
import dgl.function as fn
import os.path as osp
from dgl import DGLGraph
from dgl.data.utils import load_graphs, save_graphs
import scipy.sparse as sp
import time

warnings.simplefilter('ignore', ssp.SparseEfficiencyWarning)
cur_dir = os.path.dirname(os.path.realpath(__file__))
torch.set_printoptions(precision=8)

class MyPPRGraphDataset(Dataset):
    def __init__(self, root, entire_graph, adj_matrix, select_nghb_dict, before, node_idx, old_2_new, transform=None, pre_transform=None):
        self.root = root
        super(MyPPRGraphDataset, self).__init__(root, transform, pre_transform)
        self.entire_graph = entire_graph
        self.adj_matrix = adj_matrix
        self.select_nghb_dict = select_nghb_dict
        self.before = before
        self.node_idx = node_idx
        self.old_2_new = old_2_new
        self.cached = {}  
        self.mapping ={}

        self._process()

    @property
    def raw_file_names(self):
        return []

    @property
    def processed_file_names(self):
        return []

    def _download(self):
        pass

    def _process1(self):
        for idx in tqdm(range (len(self.node_idx))):
            subgraph = create_ppr_subgraph(self.entire_graph, self.ppr_matrix, self.node_idx, idx)
            subgraph_data = nx_to_PYGGraph(subgraph, self.entire_graph.y[self.node_idx[idx]])
            self.cached[idx] = subgraph_data


    def _process(self):
        edge_index = self.entire_graph.edge_index.numpy()
        newedge = 0

        for idx in tqdm(range (len(self.node_idx))):

            center_node = int(self.node_idx[idx])

            old_2_new_this_graph = {center_node: 0}

            edge_list = []
            edge_type = []

            old_ids = []
            old_ids.append(center_node)

            center_feature = [True]

            for etype, select_nghb in self.select_nghb_dict.items():

                ppr_neighbors = select_nghb[idx +self.before] 
                for v in ppr_neighbors:
                    if v not in old_2_new_this_graph:
                        old_2_new_this_graph[v] = len(old_2_new_this_graph)
                        center_feature.append(False)
                        old_ids.append(v)


                    if v != center_node:
                        edge_list.append([old_2_new_this_graph[center_node], old_2_new_this_graph[v] ])
                        edge_list.append([old_2_new_this_graph[v], old_2_new_this_graph[center_node] ])
                        edge_type.append(etype)
                        edge_type.append(etype)

                edge_method ="Graph"

                if edge_method == "PPR":
                    edges_set = []
                    for i in range(1, len(old_ids)):
                        node_i = old_ids[i]
                        if node_i in self.old_2_new:
                            new_node_i = self.old_2_new[node_i]
                            edges_i = set(select_nghb[new_node_i])
                        else:
                            edges_i = set()
                        edges_set.append(edges_i)

                    for i in range(1, len(old_ids)):
                        node_i = old_ids[i]
                        for j in range(i + 1, len(old_ids)):  
                            if node_i in edges_set[j - 1]:
                                edge_list.append([i, j])
                                edge_list.append([j, i])
                                edge_type.append(etype)
                                edge_type.append(etype)
                                newedge += 2

                if edge_method == "Graph":
                    edges_set = []
                    adj_matrix_type = self.adj_matrix[etype]
                    for i in range(1, len(old_ids)):
                        node_i = old_ids[i]
                        edges_i = set(adj_matrix_type.indices[adj_matrix_type.indptr[node_i]: adj_matrix_type.indptr[node_i + 1]])
                        edges_set.append(edges_i)

                    for i in range(1, len(old_ids)):
                        node_i = old_ids[i]
                        for j in range(i + 1, len(old_ids)):  
                            if node_i in edges_set[j - 1]:
                                edge_list.append([i, j])
                                edge_list.append([j, i])
                                edge_type.append(0)
                                edge_type.append(0)
                                newedge += 2

            num_nodes = len(old_2_new_this_graph)
            edge_index = torch.LongTensor(edge_list).t()
            edge_type = torch.LongTensor(edge_type)

            x = torch.tensor(np.array(old_ids), dtype=torch.long)

            y = self.entire_graph.y[self.node_idx[idx]]

            x_center_features = torch.tensor(np.array(center_feature), dtype=torch.bool)

            data = Data(x, edge_index, y=y)
            data.edge_type = edge_type
            data.graph_size = num_nodes
            data.x_center_features = x_center_features
            data.location = 0

            self.cached[center_node] = data
            cnt = len(self.cached) -1
            self.mapping[cnt] = center_node

        print(f"{newedge} edges are added among neigbhors")

    def len(self):
        pass
    def get(self,idx):
        pass

    def __len__(self) :
        r"""The number of examples in the dataset."""
        return len(self.node_idx)


    def __getitem__(self, idx):
        if isinstance(idx, int):
            key = self.mapping[idx]
        else:
            key = idx[0] 

        if key not in self.cached:
            subgraph_label = self.entire_graph.y[self.node_idx[idx]]

            ppr_subgraph= create_ppr_subgraph(self.entire_graph,self.ppr_matrix,self.node_idx,idx)
            data = nx_to_PYGGraph(ppr_subgraph,subgraph_label)
            self.cached[key]=data

        return self.cached[key]


def get_sparse_matrices(edge_type, edge_index,directed):

    if not isinstance(edge_index, np.ndarray):
        edge_index = edge_index.numpy()
    if not isinstance(edge_type, np.ndarray):
        edge_type = edge_type.numpy()

    num_edge_types = np.max(edge_type) + 1

    subgraph_matrices_csr= {}

    for edge_type_id in range(num_edge_types):
        type_mask = edge_type == edge_type_id
        subgraph_edges = edge_index[:, type_mask]

        if directed:
            matrix_csr = sp.csr_matrix((np.ones(subgraph_edges.shape[1]), (subgraph_edges[0], subgraph_edges[1])))
        else:
            undirected_edges = np.hstack([subgraph_edges, subgraph_edges[[1, 0]]])
            matrix_csr = sp.csr_matrix((np.ones(undirected_edges.shape[1]), (undirected_edges[0], undirected_edges[1])))
        subgraph_matrices_csr[edge_type_id] = matrix_csr

    return subgraph_matrices_csr


def create_ppr_subgraph(data,ppr_matrix,node_idx,idx):

    center_node = int(node_idx[idx])
    subgraph = nx.MultiGraph()

    sub_nodes = {center_node: 0}
    subgraph.add_node(0, features=center_node, original_id=center_node, center=True)

    for etype, ppr_mat in ppr_matrix.items():
        ppr_neighbors = ppr_mat[center_node].nonzero()[1]
        for v in ppr_neighbors:
            if v not in sub_nodes:
                sub_nodes[v] = len(sub_nodes)
                subgraph.add_node(sub_nodes[v], features=v, original_id=v, center=False)
            if v!=center_node:
                subgraph.add_edge(sub_nodes[center_node], sub_nodes[v], relation=etype)

    neighbors = list(sub_nodes.keys())
    neighbors.remove(center_node)  

    edge_index_np = data.edge_index.numpy()
    edge_type_np = data.edge_type.numpy()

    for i in range(len(neighbors)):
        for j in range(i + 1, len(neighbors)):  
            node_i = neighbors[i]
            node_j = neighbors[j]
            for direction in [(node_i, node_j), (node_j, node_i)]:
                mask = np.logical_and(edge_index_np[0] == direction[0], edge_index_np[1] == direction[1])
                edge_types = edge_type_np[mask]

                for edge_type in edge_types:
                    subgraph.add_edge(sub_nodes[direction[0]], sub_nodes[direction[1]], relation=edge_type)

    return subgraph


def create_enhanced_ppr_subgraph(data, ppr_matrix, node_idx, idx,topk=4):
    center_node = int(node_idx[idx])
    node_features = torch.cat(
        (data.des_embedding, data.tweet_embedding, data.num_property_embedding, data.cat_property_embedding),
        dim=1).numpy()

    subgraph = nx.MultiGraph()

    sub_nodes = {center_node: 0}
    subgraph.add_node(0, features=node_features[center_node], original_id=center_node, center=True)

    for etype, ppr_mat in ppr_matrix.items():
        ppr_neighbors = ppr_mat[center_node].nonzero()[1]
        for v in ppr_neighbors:
            if v not in sub_nodes:
                sub_nodes[v] = len(sub_nodes)
                subgraph.add_node(sub_nodes[v], features=node_features[v], original_id=v, center=False)
            if v != center_node:
                subgraph.add_edge(sub_nodes[center_node], sub_nodes[v], relation=etype)

    node_representations = data.pretrained_results
    center_node_representation = node_representations[center_node].unsqueeze(0)
    cos_similarities = F.cosine_similarity(center_node_representation, node_representations, dim=1)
    topk_values, topk_indices = torch.topk(cos_similarities, k=topk + 1)  
    mask = topk_indices != center_node
    topk_values, topk_indices = topk_values[mask][:topk].numpy(), topk_indices[mask][:topk].numpy()
    for v in topk_indices:
        if v not in sub_nodes:
            sub_nodes[v] = len(sub_nodes)
            subgraph.add_node(sub_nodes[v], features=node_features[v], original_id=v, center=False)
        for edge_type in torch.unique(data.edge_type):
            subgraph.add_edge(sub_nodes[center_node], sub_nodes[v], relation=edge_type)

    del node_representations,\
        center_node_representation,\
        cos_similarities,\
        topk_values,\
        topk_indices

    neighbors = list(sub_nodes.keys())
    neighbors.remove(center_node) 

    edge_index_np = data.edge_index.numpy()
    edge_type_np = data.edge_type.numpy()

    for i in range(len(neighbors)):
        for j in range(i + 1, len(neighbors)):  
            node_i = neighbors[i]
            node_j = neighbors[j]
            for direction in [(node_i, node_j), (node_j, node_i)]:
                mask = np.logical_and(edge_index_np[0] == direction[0], edge_index_np[1] == direction[1])
                edge_types = edge_type_np[mask]

                for edge_type in edge_types:
                    subgraph.add_edge(sub_nodes[direction[0]], sub_nodes[direction[1]], relation=edge_type)

    return subgraph

def nx_to_PYGGraph(g,g_label):
    y = g_label

    node_features = nx.get_node_attributes(g, 'features')
    x = torch.tensor(np.array(list(node_features.values())), dtype=torch.long)

    center_features= nx.get_node_attributes(g, 'center')
    x_center_features= torch.tensor(np.array(list(center_features.values())), dtype=torch.bool)

    num_nodes = len(node_features)


    edge_index_list = [] 
    edge_type_list = []  

    for u, v, attr in g.edges(data=True):
        edge_index_list.append((u, v))  
        edge_type_list.append(attr['relation'])  

    edge_index = torch.LongTensor(edge_index_list).t()

    edge_type = torch.LongTensor(edge_type_list)

    data = Data(x, edge_index, y=y)
    data.edge_type = edge_type
    data.graph_size = num_nodes
    data.x_center_features =x_center_features
    data.location = 0
    return data


def nx_to_DGLGraph(g, g_label):
    node_features = nx.get_node_attributes(g, 'features')
    center_features = nx.get_node_attributes(g, 'center')
    
    x = torch.tensor(np.array(list(node_features.values())), dtype=torch.float32)
    x_center_features = torch.tensor(np.array(list(center_features.values())), dtype=torch.bool)
    
    num_nodes = len(node_features)
    if isinstance(g_label, (int, float)) or g_label.numel() == 0 or g_label.shape == torch.Size([]):
        g_label = torch.tensor([g_label] * num_nodes, dtype=torch.long)
    elif len(g_label.shape) == 0 or g_label.numel() == 1:
        g_label = torch.tensor([g_label.item()] * num_nodes, dtype=torch.long)
    edges_src = []
    edges_dst = []
    edge_types = []
    for u, v, attr in g.edges(data=True):
        edges_src.append(u)
        edges_dst.append(v)
        edge_types.append(attr['relation'])

    g_dgl = dgl.graph((edges_src, edges_dst), num_nodes=num_nodes)

    g_dgl.ndata['feature'] = x
    g_dgl.ndata['center'] = x_center_features
    g_dgl.edata['type'] = torch.tensor(edge_types, dtype=torch.long)
    g_dgl.ndata['label'] = g_label

    return g_dgl









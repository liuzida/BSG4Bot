import os
import gc
import numba
from argparse import ArgumentParser
from utils import null_metrics,calc_metrics,is_better
import torch
from dataset import get_train_data_pretrained
from ppr_graph import MyPPRGraphDataset,create_ppr_subgraph
from torch_geometric.loader import NeighborLoader
from torch_geometric.data import DataLoader,Data
from tqdm import tqdm
import torch.nn as nn
import random
import numpy as np
import ppr
import time
from  model import HeteroBotGCN

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
parser = ArgumentParser()
parser.add_argument('--dataset', type=str, default='Twibot-22')
parser.add_argument('--visible', type=bool, default=True)
parser.add_argument('--hidden_dim', type=int, default=128)
parser.add_argument('--max_epoch', type=int, default=200)
parser.add_argument('--batch_size', type=int, default=128)
parser.add_argument('--no_up', type=int, default=50)
parser.add_argument('--lr', type=float, default=1e-3)
parser.add_argument('--weight_decay', type=float, default=1e-5)
parser.add_argument('--dropout', type=float, default=0.3)
parser.add_argument('--alpha', type=float, default=0.80)# PPR teleport probability
parser.add_argument('--eps', type=float, default=1e-4 )# Stopping threshold for ACL's ApproximatePR
parser.add_argument('--topk', type=int, default=16)# Number of PPR neighbors for each node
parser.add_argument('--ppr_normalization', type=str, default='row')# Adjacency matrix normalization for weighting neighbors
args = parser.parse_args()

dataset_name = args.dataset
visible = args.visible
hidden_dim = args.hidden_dim
dropout = args.dropout
lr = args.lr
weight_decay = args.weight_decay
max_epoch = args.max_epoch
batch_size = args.batch_size
no_up = args.no_up
alpha=args.alpha
eps=args.eps
topk=args.topk
ppr_normalization=args.ppr_normalization

assert dataset_name in ['Twibot-20', 'Twibot-22']
data = get_train_data_pretrained(dataset_name)
nodes=torch.cat((data.train_idx, data.val_idx, data.test_idx), dim=0)
ppr_matrix = ppr.topk_ppr_matrix(data, alpha, eps, nodes, topk,
                                     normalization=ppr_normalization,directed=False)
start = time.time()

train_set = MyPPRGraphDataset(root=None,
                              entire_graph=data,
                              ppr_matrix=ppr_matrix,
                              node_idx=data.train_idx)#data.train_idx#selected_data_train_idx
time_preprocessing = time.time() - start
print(f"train set subgraph extracted time: {time_preprocessing:.2f}s")


start = time.time()
val_set = MyPPRGraphDataset(  root=None,
                              entire_graph=data,
                              ppr_matrix=ppr_matrix,
                              node_idx=data.val_idx)#data.val_idx
time_preprocessing = time.time() - start
print(f"val_set subgraph extracted time: {time_preprocessing:.2f}s")


start = time.time()
test_set = MyPPRGraphDataset( root=None,
                              entire_graph=data,
                              ppr_matrix=ppr_matrix,
                              node_idx=data.test_idx)
time_preprocessing = time.time() - start
print(f"test_set subgraph extracted time: {time_preprocessing:.2f}s")




def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    random.seed(seed)
    print('set seed for random numpy and torch')

def forward_one_epoch(epoch, model, optimizer, loss_fn, train_loader, val_loader):
    model.train()
    all_label = []
    all_pred = []
    ave_loss = 0.0
    cnt = 0.0
    count = 0
    for batch in train_loader:

        optimizer.zero_grad()

        n_batch = len(batch.y)
        batch_mask=batch.x
        batch.des_embedding=data.des_embedding[batch_mask]
        batch.tweet_embedding=data.tweet_embedding[batch_mask]
        batch.num_property_embedding=data.num_property_embedding[batch_mask]
        batch.cat_property_embedding=data.cat_property_embedding[batch_mask]
        batch = batch.to(device)

        out = model(batch)

        label = batch.y[:n_batch]
        out = out[:n_batch]
        all_label += label.data
        all_pred += out
        loss = loss_fn(out, label)
        ave_loss += loss.item() * n_batch
        cnt += n_batch
        loss.backward()
        optimizer.step()
        count = count +1
    ave_loss /= cnt
    all_label = torch.stack(all_label)
    all_pred = torch.stack(all_pred)
    metrics, plog = calc_metrics(all_label, all_pred)
    plog = 'Epoch-{} train loss: {:.6}'.format(epoch, ave_loss) + plog
    if visible:
        print(plog)

    val_metrics = validation(epoch, 'validation', model, loss_fn, val_loader)
    return val_metrics


@torch.no_grad()
def validation(epoch, name, model, loss_fn, loader,pretrained=False):
    model.eval()
    all_label = []
    all_pred = []
    ave_loss = 0.0
    cnt = 0.0
    pretrained_embeddings = []
    for batch in loader:

        n_batch = len(batch.y)
        batch_mask = batch.x
        batch.des_embedding = data.des_embedding[batch_mask]
        batch.tweet_embedding = data.tweet_embedding[batch_mask]
        batch.num_property_embedding = data.num_property_embedding[batch_mask]
        batch.cat_property_embedding = data.cat_property_embedding[batch_mask]
        batch = batch.to(device)

        out = model(batch)
        if pretrained==True:
            pretrained_embeddings.append(out.cpu())

        label = batch.y[:n_batch]
        out = out[:n_batch]
        all_label += label.data
        all_pred += out
        loss = loss_fn(out, label)
        ave_loss += loss.item() * n_batch
        cnt += n_batch
    ave_loss /= cnt
    all_label = torch.stack(all_label)
    all_pred = torch.stack(all_pred)
    metrics, plog = calc_metrics(all_label, all_pred)
    plog = 'Epoch-{} {} loss: {:.6}'.format(epoch, name, ave_loss) + plog
    if visible:
        print(plog)
    if pretrained == True:
        return metrics,pretrained_embeddings
    else:
        return metrics

def train(seed):

    train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_set, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_set, batch_size=batch_size, shuffle=False)

    mode='HeteroBotGCN'
    model = HeteroBotGCN(hidden_dim=hidden_dim,
                         dropout=dropout,
                         num_prop_size=data.num_property_embedding.shape[-1],
                         cat_prop_size=data.cat_property_embedding.shape[-1],  # ,
                         num_relations=data.edge_type.max().item() + 1).to(device)




    best_val_metrics = null_metrics()
    best_state_dict = None
    loss_fn = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    pbar = tqdm(range(max_epoch), ncols=0)
    cnt = 0

    for epoch in pbar:
        start = time.time()
        val_metrics = forward_one_epoch(epoch, model, optimizer, loss_fn, train_loader, val_loader)
        print(val_metrics)
        if is_better(val_metrics, best_val_metrics):
            best_val_metrics = val_metrics
            best_state_dict = model.state_dict()
            cnt = 0
        else:
            cnt += 1
        pbar.set_postfix_str('val acc {} no up cnt {}'.format(val_metrics['acc'], cnt))
        print()
        if cnt == no_up:
            break
        if val_metrics['acc']>0.865:
            optimizer.param_groups[0]['lr'] = 1e-6
        end=time.time()
        print('time for one epoch:',end-start)

    model.load_state_dict(best_state_dict)

    test_metrics = validation(max_epoch, 'test', model, loss_fn, test_loader)

    torch.save(best_state_dict, 'saved_model/{}_{}_{}.pt'.format(dataset_name,mode,'user'+str(seed)))
    with open('result/wei_all_' + dataset_name+mode+str(seed), 'w') as file:
        for key, value in test_metrics.items():
            print(key, value, file=file)



if __name__ == '__main__':
    for i in range(4):

        set_seed(i)
        train(i)

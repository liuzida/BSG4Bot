import os
from argparse import ArgumentParser
from utils import null_metrics, calc_metrics, is_better
import torch
from dataset import get_train_data
from torch_geometric.loader import NeighborLoader
from torch.utils.data import DataLoader, TensorDataset
from tqdm import tqdm
import torch.nn as nn
import random
import numpy as np
from  model import MLP
import time

parser = ArgumentParser()
parser.add_argument('--dataset', type=str, default='Twibot-22')
parser.add_argument('--visible', type=bool, default=True)
parser.add_argument('--hidden_dim', type=int, default=128)
parser.add_argument('--max_epoch', type=int, default=100)
parser.add_argument('--batch_size', type=int, default=256)
parser.add_argument('--no_up', type=int, default=50)
parser.add_argument('--lr', type=float, default=1e-3)
parser.add_argument('--weight_decay', type=float, default=1e-5)
parser.add_argument('--dropout', type=float, default=0.3)
parser.add_argument('--pretrained', type=bool, default=False)
parser.add_argument('--extend', type=bool, default='True')# debug info
parser.add_argument('--factor', type=int, default='4')
parser.add_argument('--new_edge_ratio', type=float, default='0.2')
parser.add_argument('--bot_2_human', type=float, default='0.8') 
parser.add_argument('--human_2_bot', type=float, default='0.05') 
parser.add_argument('--impact_node_ratio', type=float, default='0.2')# debug info
args = parser.parse_args()

dataset_name = args.dataset
visible = args.visible
device = torch.device('cuda')

assert dataset_name in ['Twibot-20', 'Twibot-22']

hidden_dim = args.hidden_dim
dropout = args.dropout
lr = args.lr
weight_decay = args.weight_decay
max_epoch = args.max_epoch
batch_size = args.batch_size
no_up = args.no_up


def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    random.seed(seed)
    print('set seed for random numpy and torch')

def forward_one_epoch(epoch, model, optimizer, loss_fn, train_loader, val_loader):
    print(epoch)
    model.train()
    all_label = []
    all_pred = []
    ave_loss = 0.0
    cnt = 0.0
    count = 0
    for batch in train_loader:
        optimizer.zero_grad()
        batch = batch.to(device)
        n_batch = batch.batch_size
        out,embedding = model(batch.des_embedding,
                    batch.tweet_embedding,
                    batch.num_property_embedding,
                    batch.cat_property_embedding,
                    batch.edge_index,
                    batch.edge_type)

        label = batch.y[:n_batch]
        out = out[:n_batch]
        all_label += label.data
        all_pred += out
        loss = loss_fn(out, label)
        ave_loss += loss.item() * n_batch
        cnt += n_batch
        loss.backward()
        nn.utils.clip_grad_value_(model.parameters(), 1000)
        optimizer.step()
        count = count +1

    ave_loss /= cnt
    all_label = torch.stack(all_label)
    all_pred = torch.stack(all_pred)
    metrics, plog = calc_metrics(all_label, all_pred)
    plog = 'Epoch-{} train loss: {:.6}'.format(epoch, ave_loss) + plog
    if visible:
        print(plog)
    return metrics


@torch.no_grad()
def validation(epoch, name, model, loss_fn, loader,pretrained=False):
    model.eval()
    all_label = []
    all_pred = []
    ave_loss = 0.0
    cnt = 0.0
    pretrained_embeddings = []
    for batch in loader:
        batch = batch.to(device)
        n_batch = batch.batch_size
        out,embedding = model(batch.des_embedding,
                    batch.tweet_embedding,
                    batch.num_property_embedding,
                    batch.cat_property_embedding,
                    batch.edge_index,
                    batch.edge_type)
        if pretrained==True:
            pretrained_embeddings.append(embedding.cpu())

        label = batch.y[:n_batch]
        out = out[:n_batch]
        all_label += label.data
        all_pred += out
        loss = loss_fn(out, label)
        ave_loss += loss.item() * n_batch
        cnt += n_batch
    ave_loss /= cnt
    all_label = torch.stack(all_label)
    all_pred = torch.stack(all_pred)
    metrics, plog = calc_metrics(all_label, all_pred)
    plog = 'Epoch-{} {} loss: {:.6}'.format(epoch, name, ave_loss) + plog
    if visible:
        print(plog)
    if pretrained == True:
        return metrics,pretrained_embeddings
    else:
        return metrics

def train(seed):
    train_loader = NeighborLoader(data,
                                  num_neighbors=[0] * 4,
                                  batch_size=batch_size,
                                  input_nodes=train_index,
                                  shuffle=True,
                                  )
    val_loader = NeighborLoader(data,
                                num_neighbors=[0] * 4,
                                batch_size=batch_size,
                                input_nodes=val_index,
                                )

    test_loader = NeighborLoader(data,
                                 num_neighbors=[0] * 4,
                                 batch_size=batch_size,
                                 input_nodes=test_index)

    pretrained_loader=NeighborLoader(data,
                                 num_neighbors=[0] * 4,
                                 batch_size=batch_size,
                                 input_nodes=pre_trained_test_index)


    mode='mlp'
    model = MLP(hidden_dim=hidden_dim,
                dropout=dropout,
                num_prop_size=data.num_property_embedding.shape[-1],
                cat_prop_size=data.cat_property_embedding.shape[-1]).to(device)

    best_val_metrics = null_metrics()
    best_state_dict = None
    loss_fn = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    pbar = tqdm(range(max_epoch), ncols=0)
    cnt = 0

    for epoch in pbar:

        val_metrics = forward_one_epoch(epoch, model, optimizer, loss_fn, train_loader, val_loader)
        print(val_metrics)
        if is_better(val_metrics, best_val_metrics):
            best_val_metrics = val_metrics
            best_state_dict = model.state_dict()
            cnt = 0
        else:
            cnt += 1
        pbar.set_postfix_str('val acc {} no up cnt {}'.format(val_metrics['acc'], cnt))
        if cnt == no_up:
            break
    model.load_state_dict(best_state_dict)

    test_metrics = validation(max_epoch, 'test', model, loss_fn, test_loader,pretrained=False)

    pretrained_metrics,pretrained_embeddings = validation(max_epoch, 'test', model, loss_fn, pretrained_loader,pretrained=True)
    pretrained_embeddings=torch.cat(pretrained_embeddings, dim=0)
    torch.save(pretrained_embeddings, 'pretrained/pretrained_embedding.pt')


def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    random.seed(seed)
    print('set seed for random numpy and torch')

if __name__ == '__main__':
    data = get_train_data(dataset_name, args)
    node_num = data.node_num_origin

    train_ratio = 0.1
    val_ratio = 0.6
    test_ratio = 0.3

    train_end =int (node_num * train_ratio)
    val_end = int (node_num * (train_ratio +val_ratio))
    test_end = int (node_num * (train_ratio +val_ratio+test_ratio))


    train_index = torch.arange(0, train_end)
    val_index = torch.arange(train_end, val_end)
    test_index = torch.arange(val_end, test_end)
    pre_trained_test_index = torch.cat((train_index, val_index, test_index), dim=0)
    
    for i in range(4)
        set_seed(i)
        time_start = time.time()
        train(i)
        time_end = time.time()
        print('time cost: ', time_end - time_start, 's')
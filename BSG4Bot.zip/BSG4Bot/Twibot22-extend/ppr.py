import time

import networkx as nx
import numba
from numba import jit, prange, njit

import numpy as np
import torch
import scipy.sparse as sp
from sklearn.metrics.pairwise import cosine_similarity
from scipy.sparse import find
from collections import defaultdict
from tqdm import tqdm

from typing import List


def topk_ppr_matrix(data, alpha, eps, node_idx, topk, normalization='row',directed=True):

    print(directed)

    num_nodes = len(data.y)

    adj_matrix_all = get_sparse_matrices(data.y,data.edge_type,data.edge_index,directed)

    """Create a sparse matrix where each node has up to the topk PPR neighbors and their weights."""
    print('adj_matrix done')

    topk_matrix = {}
    for edge_type, adj_matrix in adj_matrix_all.items():



        ppr_nghbs, ppr_wgts = ppr_topk(adj_matrix, alpha, eps, node_idx.numpy(), topk)


        if normalization == 'sym':
            # Assume undirected (symmetric) adjacency matrix
            deg = adj_matrix.sum(1).A1
            deg_sqrt = np.sqrt(np.maximum(deg, 1e-12))
            deg_inv_sqrt = 1. / deg_sqrt

            row, col = topk_matrix.nonzero()
            # assert np.all(deg[idx[row]] > 0)
            # assert np.all(deg[col] > 0)
            topk_matrix.data = deg_sqrt[node_idx[row]] * topk_matrix.data * deg_inv_sqrt[col]
        elif normalization == 'col':
            # Assume undirected (symmetric) adjacency matrix
            deg = adj_matrix.sum(1).A1
            deg_inv = 1. / np.maximum(deg, 1e-12)

            row, col = topk_matrix.nonzero()
            # assert np.all(deg[idx[row]] > 0)
            # assert np.all(deg[col] > 0)
            topk_matrix.data = deg[node_idx[row]] * topk_matrix.data * deg_inv[col]
        elif normalization == 'row':
            pass
        else:
            raise ValueError(f"Unknown PPR normalization: {normalization}")

        node_features = data.pretrained_results.detach().numpy()

        # node_features = (node_features - np.average(node_features, 0)) / np.std(node_features, 0)

        y = data.y.detach().numpy()

        node_neigbhors = get_biased_ppr_matrix_weig(node_features, y, node_idx.numpy(), ppr_nghbs, ppr_wgts, topk,
                                                    num_nodes)  # 偏置 PPR 矩阵: 在 PPR 矩阵上施加额外的权重或调整，以使矩阵更适合特定应用需求

        # coo_matrix = sp.coo_matrix((vals, (rows, cols)), shape=(node_features.shape[0], node_features.shape[0]))

        topk_matrix[edge_type] = node_neigbhors

    return topk_matrix, adj_matrix_all



def topk_ppr_matrix_ts(data, alpha, eps, node_idx, topk, normalization='row',directed=True):



    adj_matrix_all = get_sparse_matrices(data.edge_type,data.edge_index,directed)

    """Create a sparse matrix where each node has up to the topk PPR neighbors and their weights."""
    num_nodes = len(data.y)

    topk_matrix = {}
    for edge_type, adj_matrix in adj_matrix_all.items():#返回 subgraph_matrices_csr 字典中的所有 (key, value) 对,edge_id,csr_matrix


        start = time.time()
        ppr_nghbs, ppr_wgts = ppr_topk(adj_matrix, alpha, eps, node_idx.numpy(), topk) #.tocsr()

        time_preprocessing = time.time() - start
        print(f"Finish Computing PPR: {time_preprocessing:.2f}s")
        '''
        对称归一化
        计算每个节点的度数 deg。
        计算度数的平方根 deg_sqrt 和其倒数 deg_inv_sqrt。
        使用 topk_matrix.nonzero() 获取 PPR 矩阵的非零元素的行和列索引。
        使用度数的平方根和其倒数对 PPR 矩阵的非零元素进行归一化
        '''
        if normalization == 'sym':
            # Assume undirected (symmetric) adjacency matrix
            deg = adj_matrix.sum(1).A1
            deg_sqrt = np.sqrt(np.maximum(deg, 1e-12))
            deg_inv_sqrt = 1. / deg_sqrt

            row, col = topk_matrix.nonzero()
            # assert np.all(deg[idx[row]] > 0)
            # assert np.all(deg[col] > 0)
            topk_matrix.data = deg_sqrt[idx[row]] * topk_matrix.data * deg_inv_sqrt[col]
            '''
            列归一化
            计算每个节点的度数 deg。
            计算度数的倒数 deg_inv。
            使用 topk_matrix.nonzero() 获取 PPR 矩阵的非零元素的行和列索引。
            使用度数和其倒数对 PPR 矩阵的非零元素进行归一化。
            '''
        elif normalization == 'col':
            # Assume undirected (symmetric) adjacency matrix
            deg = adj_matrix.sum(1).A1
            deg_inv = 1. / np.maximum(deg, 1e-12)

            row, col = topk_matrix.nonzero()
            # assert np.all(deg[idx[row]] > 0)
            # assert np.all(deg[col] > 0)
            topk_matrix.data = deg[idx[row]] * topk_matrix.data * deg_inv[col]
        elif normalization == 'row':
            pass
        else:
            raise ValueError(f"Unknown PPR normalization: {normalization}")

        node_features = data.pretrained_results.detach().numpy()

        #node_features = (node_features - np.average(node_features, 0)) / np.std(node_features, 0)

        y = data.y.detach().numpy()

        node_neigbhors = get_biased_ppr_matrix_weig(node_features, y,  node_idx.numpy(), ppr_nghbs, ppr_wgts, topk, num_nodes)#偏置 PPR 矩阵: 在 PPR 矩阵上施加额外的权重或调整，以使矩阵更适合特定应用需求

        #coo_matrix = sp.coo_matrix((vals, (rows, cols)), shape=(node_features.shape[0], node_features.shape[0]))

        topk_matrix[edge_type] = node_neigbhors



    return topk_matrix




@numba.njit(cache=True)
def normalize_scores(scores):
    """归一化得分到[0, 1]区间."""
    min_score = np.min(scores)
    max_score = np.max(scores)
    if max_score > min_score:
        return (scores - min_score) / (max_score - min_score)
    else:
        return scores


@numba.njit(cache=True)
def cosine_similarity_numba(X, Y=None):
    X = np.asarray(X)
    if Y is None:
        Y = X
    else:
        Y = np.asarray(Y)

    if X.shape[1] != Y.shape[1]:
        raise ValueError("Incompatible array sizes for X and Y")

    dot_products = np.dot(X, Y.T)

    norms_X = np.sqrt(np.sum(X ** 2, axis=1))
    norms_Y = np.sqrt(np.sum(Y ** 2, axis=1))

    norms_product = np.outer(norms_X, norms_Y)
    similarity = dot_products / (norms_product + 1e-9)  # 防止0
    return similarity


@numba.njit(cache=False)
def get_biased_ppr_matrix_weig(node_features, y, select_nodes, ppr_nghbs, ppr_wgts, topk, N):
    #  # data.pretrained_results是一个PyTorch Tensor

    #rows, cols, vals = [], [], []

    select_nghbs = [np.zeros(0, dtype=np.int64) ]* (len(select_nodes))

    #vals = [np.zeros(0, dtype=np.float32)] * N

    #for i in prange(node_features.shape[0]):

    wrong0, wrong1, correct0, correct1 = 0, 0, 0, 0
    best1 = 0

    for i in prange(len(select_nodes)):

        node_id_in_graph = select_nodes[i].item()

        neighbors = ppr_nghbs[i]
        ppr_values = ppr_wgts[i]



        if len(neighbors) == 0:
            continue

        #if i % 100000 ==0:
        #    print(i)

        rootlabel = y[node_id_in_graph]


        """
        cnt = 0
        for ngb in neighbors.tolist():
            if rootlabel == y[ngb]:
                cnt = cnt + 1
        """

        #print(f"{cnt} of out {len(neighbors)} are the same")


        # 检查并移除中心节点自己
        if node_id_in_graph in neighbors:
            center_index = np.where(neighbors == node_id_in_graph)[0]#加0是因为np.where返回的是一个array,提取其中的第一个元素（也只有一个）
            neighbors = np.delete(neighbors, center_index)
            ppr_values = np.delete(ppr_values, center_index)

        if len(neighbors) == 0:  # 如果移除中心节点后没有邻居，则跳过
            continue

        # PPR值和余弦相似度的归一化,函数需要手写实现
        ppr_values_normalized = normalize_scores(ppr_values)
        center_feature = node_features[i].reshape(1, -1)
        neighbor_features = node_features[neighbors]
        similarities = cosine_similarity_numba(center_feature, neighbor_features).flatten()
        normalized_similarities = normalize_scores(similarities)

        # 计算正则化相似度与归一化PPR值的乘积
        content_weight = 1
        scores = normalized_similarities * content_weight + ppr_values_normalized * (1 - content_weight)

        # 选择乘积最大的topk个邻居
        topk_indices = np.argsort(scores)[-topk:]
        select_nghbs[i] = neighbors[topk_indices]



        cnt =0
        for ngb in select_nghbs[i]:
            if rootlabel == y[ngb]:
                cnt = cnt +1

        if rootlabel == 0:
            if cnt / len(select_nghbs[i]) < 0.5:
                wrong0 += 1
            else:
                correct0 += 1

        if rootlabel == 1:
            if cnt / len(select_nghbs[i]) < 0.5:
                wrong1 += 1
            else:
                correct1 += 1

    print(f"Wrong 95: {wrong0} for label 0 ， {wrong1} for label 1， out of total {len(select_nodes)} ")
    print(f"Correct: {correct0} for label 0 ， {correct1} for label 1， out of total {len(select_nodes)} ")
    print((wrong0 + wrong1) / len(select_nodes))

    return select_nghbs


@numba.njit(cache=True, locals={'_val': numba.float32, 'res': numba.float32, 'res_vnode': numba.float32})
def _calc_ppr_node(inode, indptr, indices, deg, alpha, epsilon, N):  
    alpha_eps = alpha * epsilon
    f32_0 = numba.float32(0)
    p = {inode: f32_0}
    r = {}
    r[inode] = alpha
    q = [inode]
    while len(q) > 0:
        unode = q.pop()

        res = r[unode] if unode in r else f32_0
        if unode in p:
            p[unode] += res
        else:
            p[unode] = res
        r[unode] = f32_0

        for vnode in indices[indptr[unode]:indptr[unode + 1]]:
            if deg[unode] == 0:
                _val = (1 - alpha) * res / max(deg[unode], 1)
            else:
                _val = (1 - alpha) * res / deg[unode]  
            if vnode in r:
                r[vnode] += _val
            else:
                r[vnode] = _val

            res_vnode = r[vnode] if vnode in r else f32_0
            if res_vnode >= alpha_eps * deg[vnode]:
                if vnode not in q:
                    q.append(vnode)

    return list(p.keys()), list(p.values())




@numba.njit(cache=True)
def calc_ppr(indptr, indices, deg, alpha, epsilon, nodes):
    js = []
    vals = []
    for i, node in enumerate(nodes):
        j, val = _calc_ppr_node(node, indptr, indices, deg, alpha, epsilon)
        js.append(j)
        vals.append(val)
    return js, vals

@numba.njit(cache=True)
def get_biased_ppr_matrix_weig_gj(node_features, y, select_nodes, ppr_nghbs, ppr_wgts, topk, N):

    select_nghbs = [np.zeros(0, dtype=np.int64) ]* (len(select_nodes))

    wrongselected = [0, 0]
    correctselected = [0, 0]

    for i in prange(len(select_nodes)):

        node_id_in_graph = select_nodes[i].item()

        neighbors = ppr_nghbs[i]
        ppr_values = ppr_wgts[i]

        if len(neighbors) == 0:
            continue

        if i % 100000 ==0:
            print(i)

        if node_id_in_graph in neighbors:
            center_index = np.where(neighbors == node_id_in_graph)[0]
            neighbors = np.delete(neighbors, center_index)
            ppr_values = np.delete(ppr_values, center_index)

        if len(neighbors) == 0:  
            continue

        min_score = np.min(ppr_values)
        max_score = np.max(ppr_values)
        if max_score > min_score:
            ppr_values_normalized = (ppr_values - min_score) / (max_score - min_score)
        else:
            ppr_values_normalized = ppr_values

        center_feature = node_features[node_id_in_graph].reshape(1, -1)
        #norms1 = np.einsum("ij,ij->i", center_feature, center_feature)
        norms = (center_feature @ center_feature.T).flatten()

        #norms = xp.asarray(norms)
        norms = np.sqrt(norms)
        center_feature /= norms[:, None]

        neighbor_features = node_features[neighbors]
        #norms1 = np.einsum("ij,ij->i", neighbor_features, neighbor_features)
        # norms = xp.asarray(norms)
        norms = np.sum(neighbor_features * neighbor_features, axis=1).flatten()
        norms = np.sqrt(norms)
        neighbor_features /= norms[:, None]

        similarities = (neighbor_features @ center_feature.T).flatten()

        #之前的计算
        #normalized_similarities_old = normalize_scores(similarities)

        #新的计算
        min_score = np.min(similarities)
        max_score = np.max(similarities)
        if max_score > min_score:
            normalized_similarities = (similarities - min_score) / (max_score - min_score)
        else:
            normalized_similarities = similarities

        # 计算正则化相似度与归一化PPR值的乘积
        content_weight = 0.85
        scores = normalized_similarities * content_weight + ppr_values_normalized * (1 - content_weight)

        # 选择乘积最大的topk个邻居
        topk_indices = np.argsort(scores)[-topk:]
        select_nghbs[i] = neighbors[topk_indices]

        rootlabel = y[node_id_in_graph]

        cnt =0
        for ngb in select_nghbs[i]:
            if rootlabel == y[ngb]:
                cnt = cnt +1

        if cnt/len(select_nghbs[i])<0.5:
            #print(f"{cnt} ouf of {len(select_nghbs[i])} is the same with label {rootlabel}")
            wrongselected[rootlabel] = wrongselected[rootlabel] +1
        else:
            correctselected[rootlabel] = correctselected[rootlabel] + 1

        #topk_scores = scores[topk_indices]

        #select_neighbors.extend([topk_neighbors])

        #rows.extend([i] * len(topk_neighbors))
        #cols.extend(topk_neighbors)
        #vals.extend(topk_scores)
        #vals.extend([1] * len(topk_neighbors))
        #select_nghbs[i] =topk_neighbors


    #return new_sparse_matrix

    print(f"{wrongselected[0] } for label 0 ， {wrongselected[1]} for label 1， out of total {len(select_nodes)} ")

    return select_nghbs



@numba.njit(cache=False, parallel=True)
def calc_ppr_topk_parallel(indptr, indices, deg, alpha, epsilon, nodes, topk, N):
    js = [np.zeros(0, dtype=np.int64)] * len(nodes)
    vals = [np.zeros(0, dtype=np.float32)] * len(nodes)
    '''
    js 用于存储每个节点的邻居索引。
    vals 用于存储每个节点的邻居权重。
    '''
    for i in numba.prange(len(nodes)):#使用 numba 进行并行计算，提升性能。
        j, val = _calc_ppr_node(nodes[i], indptr, indices, deg, alpha, epsilon,N)
        j_np, val_np = np.array(j), np.array(val)
        idx_topk = np.argsort(val_np)[-val_np.shape[0]:]#使用 np.argsort(val_np) 对 val_np 进行排序，并返回排序后的索引
        #idx_topk = np.argsort(val_np)[-topk:]
        js[i] = j_np[idx_topk]
        vals[i] = val_np[idx_topk]


    return js, vals

@numba.njit(cache=True, parallel=True)
def calc_ppr_topk_parallel_gj(indptr, indices, deg, alpha, epsilon, nodes, topk, N):
    js = [np.zeros(0, dtype=np.int64)] *  len(nodes)
    vals = [np.zeros(0, dtype=np.float32)] * len(nodes)
    '''
    js 用于存储每个节点的邻居索引。
    vals 用于存储每个节点的邻居权重。
    '''
    for i in numba.prange(len(nodes)):#使用 numba 进行并行计算，提升性能。
        j, val = _calc_ppr_node(nodes[i], indptr, indices, deg, alpha, epsilon,N)
        j_np, val_np = np.array(j), np.array(val)
        idx_topk = np.argsort(val_np)[-val_np.shape[0]:]#使用 np.argsort(val_np) 对 val_np 进行排序，并返回排序后的索引
        #idx_topk = np.argsort(val_np)[-topk:]
        js[i] = j_np[idx_topk]
        vals[i] = val_np[idx_topk]


    return js, vals


def ppr_topk(adj_matrix, alpha, epsilon, nodes, topk):
    """Calculate the PPR matrix approximately using Anderson."""
    N = max(adj_matrix.shape[0],adj_matrix.shape[1])#得到节点数量
    out_degree = np.sum(adj_matrix > 0, axis=1).A1#np.sum(..., axis=1): 在每一行上进行求和操作得到出度，.A1: 将结果转换为一维数组。A1 是 scipy.sparse 矩阵的一种方法，用于将稀疏矩阵转换为 NumPy 数组。
    #in_degree = np.sum(adj_matrix > 0, axis=0).A1


    #nnodes = adj_matrix.shape[0]
    nnodes = max(adj_matrix.shape[0],adj_matrix.shape[1])
    #print(np.count_nonzero(out_degree == 0))
    #out_degree = np.sum(adj_matrix > 0, axis=1).A1
    '''
    indptr: CSR 矩阵的行指针数组，表示每行在 indices 和 data 数组中的起始位置。
    indices: CSR 矩阵的列索引数组。两个合并对应于在原来稀疏矩阵的位置
    deg: 节点的度数数组（可能是出度或入度）。
    '''

    neighbors, weights = calc_ppr_topk_parallel(adj_matrix.indptr, adj_matrix.indices, out_degree,
                                                numba.float32(alpha), numba.float32(epsilon), nodes, topk,N)
    weights = [w / np.sum(w) for w in weights]#对每个节点的 PPR 权重进行归一化处理，使得每个节点的权重和为 1。

    #return construct_sparse(neighbors, weights, (len(nodes), nnodes),alpha)
    return neighbors, weights


def construct_sparse(neighbors, weights, shape,alpha):#map(len, neighbors): 计算每个节点的邻居数量。
    i = np.repeat(np.arange(len(neighbors)), np.fromiter(map(len, neighbors), dtype=int))#np.repeat: 重复节点索引，使得每个节点索引重复的次数等于该节点的邻居数量
    #np.fromiter(map(len, neighbors), dtype=int): 将上述 map 对象转换为 NumPy 数组。
    j = np.concatenate(neighbors)#np.concatenate(neighbors): 将所有邻居节点连接在一起，生成稀疏矩阵的列索引。
    data = np.concatenate(weights)#np.concatenate(weights): 将所有权重连接在一起，生成稀疏矩阵的非零数据。
    return sp.coo_matrix((data, (i, j)), shape)


def get_sparse_matrices(num, edge_type, edge_index,directed):

    if not isinstance(edge_index, np.ndarray):
        edge_index = edge_index.numpy()
    if not isinstance(edge_type, np.ndarray):
        edge_type = edge_type.numpy()

    num_node=len(num)
    num_edge_types = np.max(edge_type) + 1

    subgraph_matrices_csr= {}

    for edge_type_id in range(num_edge_types):
        type_mask = edge_type == edge_type_id
        subgraph_edges = edge_index[:, type_mask]


        if directed:
            matrix_csr = sp.csr_matrix((np.ones(subgraph_edges.shape[1]), (subgraph_edges[0], subgraph_edges[1])),shape=[num_node,num_node])
        else:
            undirected_edges = np.hstack([subgraph_edges, subgraph_edges[[1, 0]]])
            matrix_csr = sp.csr_matrix((np.ones(undirected_edges.shape[1]), (undirected_edges[0], undirected_edges[1])),shape=[num_node,num_node])
        subgraph_matrices_csr[edge_type_id] = matrix_csr


    return subgraph_matrices_csr


def get_biased_ppr_matrix0(data, ppr_matrix, topk):
    # 使用data.pretrained_results作为节点特征的表示
    node_features = data.pretrained_results.numpy()  # 假设data.pretrained_results是一个PyTorch Tensor

    # 创建一个空的列表来保存新的稀疏矩阵的数据
    rows, cols, vals = [], [], []

    # 遍历每个中心节点
    for i in range(ppr_matrix.shape[0]):
        # 获取当前中心节点的邻居和相应的PPR分数
        neighbors = ppr_matrix[i].nonzero()[1]
        ppr_values = ppr_matrix[i].data

        if len(neighbors) == 0:
            continue

        # 计算中心节点与其邻居之间的相似度
        center_feature = node_features[i].reshape(1, -1)
        neighbor_features = node_features[neighbors]
        similarities = cosine_similarity(center_feature, neighbor_features).flatten()

        # 将相似度正则化到[0, 1]
        normalized_similarities = (similarities + 1) / 2

        # 计算正则化相似度与PPR值的乘积
        scores = normalized_similarities * ppr_values
        #scores = normalized_similarities * ppr_values
        # 选择乘积最大的topk个邻居
        topk_indices = np.argsort(scores)[-topk:]
        topk_neighbors = neighbors[topk_indices]
        topk_scores = scores[topk_indices]

        # 更新新的稀疏矩阵的数据
        rows.extend([i] * len(topk_neighbors))
        cols.extend(topk_neighbors)
        vals.extend(topk_scores)

    # 构造新的稀疏矩阵
    new_sparse_matrix = sp.coo_matrix((vals, (rows, cols)), shape=ppr_matrix.shape)

    return new_sparse_matrix


"""
def normalize_scores(scores):
    
    min_score = np.min(scores)
    max_score = np.max(scores)
    if max_score > min_score:
        return (scores - min_score) / (max_score - min_score)
    else:
        return scores
"""

def get_biased_ppr_matrix_mul(data, ppr_matrix, topk):
    node_features = data.pretrained_results.numpy()
    rows, cols, vals = [], [], []

    for i in range(ppr_matrix.shape[0]):
        neighbors = ppr_matrix[i].nonzero()[1]
        ppr_values = ppr_matrix[i].data

        if len(neighbors) == 0:
            continue

        # 移除中心节点自身
        if i in neighbors:
            center_index = np.where(neighbors == i)[0]
            neighbors = np.delete(neighbors, center_index)
            ppr_values = np.delete(ppr_values, center_index)

        if len(neighbors) == 0:
            continue

        # 归一化PPR值
        ppr_values_normalized = normalize_scores(ppr_values)

        # 计算余弦相似度
        center_feature = node_features[i].reshape(1, -1)
        neighbor_features = node_features[neighbors]
        similarities = cosine_similarity(center_feature, neighbor_features).flatten()

        # 归一化余弦相似度
        normalized_similarities = normalize_scores(similarities)

        # 使用PPR值和余弦相似度的乘积作为权重
        final_scores = ppr_values_normalized * normalized_similarities

        # 选择权重最大的topk个邻居
        topk_indices = np.argsort(final_scores)[-topk:]
        topk_neighbors = neighbors[topk_indices]
        topk_scores = final_scores[topk_indices]

        rows.extend([i] * len(topk_neighbors))
        cols.extend(topk_neighbors)
        vals.extend(topk_scores)

    # 构建新的稀疏矩阵
    new_sparse_matrix = sp.coo_matrix((vals, (rows, cols)), shape=ppr_matrix.shape)
    return new_sparse_matrix


#@jit(nopython=True, parallel=True)
#@numba.jit(parallel=True, nonpython=True)
#@numba.njit(cache=True, parallel=True)







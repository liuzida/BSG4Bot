import os
import gc
import numba
from argparse import ArgumentParser
from utils import null_metrics,calc_metrics,is_better
import torch
from dataset import get_train_data
from ppr_graph import MyPPRGraphDataset,create_ppr_subgraph,create_enhanced_ppr_subgraph
from torch_geometric.loader import NeighborLoader
from torch_geometric.data import DataLoader,Data
from tqdm import tqdm
import torch.nn as nn
import random
import numpy as np
import ppr
import time
from  model import HeteroBotGCN,BotRGCN,BotGCN,BotGAT,MeanBotGCN,LayerBotGCN
import math

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
parser = ArgumentParser()
parser.add_argument('--dataset', type=str, default='Twibot-22')
parser.add_argument('--visible', type=bool, default=True)
parser.add_argument('--hidden_dim', type=int, default=128)
parser.add_argument('--max_epoch', type=int, default=200)
parser.add_argument('--batch_size', type=int, default=256)
parser.add_argument('--no_up', type=int, default=50)
parser.add_argument('--lr', type=float, default=1e-3)
parser.add_argument('--weight_decay', type=float, default=1e-5)
parser.add_argument('--dropout', type=float, default=0.3)
parser.add_argument('--alpha', type=float, default=0.6)# PPR teleport probability
parser.add_argument('--eps', type=float, default=1e-4 )# Stopping threshold for ACL's ApproximatePR
parser.add_argument('--pretrained', type=bool, default=True)
parser.add_argument('--topk', type=int, default=16)# Number of PPR neighbors for each node
parser.add_argument('--ppr_normalization', type=str, default='row')# Adjacency matrix normalization for weighting neighbors
parser.add_argument('--detail', type=bool, default='False')# debug info
parser.add_argument('--extend', type=bool, default='False')# debug info
parser.add_argument('--factor', type=int, default='4')
parser.add_argument('--new_edge_ratio', type=float, default='0.2')
parser.add_argument('--bot_2_human', type=float, default='0.8') 
parser.add_argument('--human_2_bot', type=float, default='0.05') 
parser.add_argument('--impact_node_ratio', type=float, default='0.2')
args = parser.parse_args()

dataset_name = args.dataset
visible = args.visible
hidden_dim = args.hidden_dim
dropout = args.dropout
lr = args.lr
weight_decay = args.weight_decay
max_epoch = args.max_epoch
batch_size = args.batch_size
no_up = args.no_up
alpha=args.alpha
eps=args.eps
topk=args.topk
ppr_normalization=args.ppr_normalization

train_ratio = 0.7
val_ratio = 0.2
test_ratio = 0.1

dataset_name='Twibot-22'
data = get_train_data(dataset_name, args)

def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    random.seed(seed)
    print('set seed for random numpy and torch')

set_seed(3407)

train_node_num = data.node_num_origin
node_num = len(data.y)  

train_end = int(train_node_num * train_ratio)
train_index = torch.randperm(train_node_num)[:train_end]
val_size = int(train_node_num * val_ratio)
test_size = int(train_node_num * test_ratio)
shuffled_indices = torch.randperm(node_num - train_node_num) + train_node_num
val_index = shuffled_indices[:val_size]
test_index = shuffled_indices[val_size:val_size + test_size]
nodes=torch.cat((train_index, val_index, test_index), dim=0)

old_2_new  ={}
for i in  range(len(nodes)):
    old_2_new[nodes[i].item()] = i

start = time.time()
select_neighbors, adj_matrix = ppr.topk_ppr_matrix(data, alpha, eps, nodes, topk,
                                     normalization=ppr_normalization,directed=False)

time_preprocessing = time.time() - start
print(f"ppr time: {time_preprocessing}s")

start_subgraph = time.time()
output_dir = 'subgraph_social'

train_set = MyPPRGraphDataset(root=None,
                              entire_graph=data,
                              adj_matrix=adj_matrix,
                              select_nghb_dict=select_neighbors,
                              before  = 0,
                              node_idx=train_index,
                              old_2_new = old_2_new)
print(f"train set subgraph extracted time: {time.time() - start_subgraph}s")

start = time.time()
val_set = MyPPRGraphDataset(  root=None,
                              entire_graph=data,
                              adj_matrix=adj_matrix,
                              select_nghb_dict=select_neighbors,
                              before = len(train_index),
                              node_idx=val_index,
                              old_2_new = old_2_new
                              )
time_preprocessing = time.time() - start
print(f"val_set subgraph extracted time: {time_preprocessing}s")

start = time.time()
test_set = MyPPRGraphDataset( root=None,
                              entire_graph=data,
                              adj_matrix=adj_matrix,
                              select_nghb_dict=select_neighbors,
                              before = len(train_index) + len(val_index),
                              node_idx=test_index,
                              old_2_new = old_2_new
                              )
time_preprocessing = time.time() - start
print(f"test_set subgraph extracted time: {time_preprocessing}s")


print(f"******the cost in building subgraphs is : {time.time() - start_subgraph}s")



def forward_one_epoch(epoch, model, optimizer, loss_fn, train_loader, val_loader):
    model.train()
    all_label = []
    all_pred = []
    ave_loss = 0.0
    cnt = 0.0
    count = 0
    for batch in train_loader:

        optimizer.zero_grad()

        n_batch = len(batch.y)
        batch_mask=batch.x
        batch.des_embedding=data.des_embedding[batch_mask]
        batch.tweet_embedding=data.tweet_embedding[batch_mask]
        batch.num_property_embedding=data.num_property_embedding[batch_mask]
        batch.cat_property_embedding=data.cat_property_embedding[batch_mask]
        batch = batch.to(device)

        out = model(batch)

        label = batch.y[:n_batch]
        out = out[:n_batch]
        all_label += label.data
        all_pred += out
        loss = loss_fn(out, label)
        ave_loss += loss.item() * n_batch
        cnt += n_batch
        loss.backward()
        optimizer.step()
        count = count +1
    ave_loss /= cnt
    all_label = torch.stack(all_label)
    all_pred = torch.stack(all_pred)
    metrics, plog = calc_metrics(all_label, all_pred)
    if args.detail:
        plog = 'Epoch-{} train loss: {:.6}'.format(epoch, ave_loss) + plog
        print(plog)

    val_metrics = validation(epoch, 'validation', model, loss_fn, val_loader)
    return val_metrics


@torch.no_grad()
def validation(epoch, name, model, loss_fn, loader,pretrained=False):
    model.eval()
    all_label = []
    all_pred = []
    ave_loss = 0.0
    cnt = 0.0
    pretrained_embeddings = []
    for batch in loader:

        n_batch = len(batch.y)
        batch_mask = batch.x
        batch.des_embedding = data.des_embedding[batch_mask]
        batch.tweet_embedding = data.tweet_embedding[batch_mask]
        batch.num_property_embedding = data.num_property_embedding[batch_mask]
        batch.cat_property_embedding = data.cat_property_embedding[batch_mask]
        batch = batch.to(device)

        out = model(batch)
        if pretrained==True:
            pretrained_embeddings.append(out.cpu())

        label = batch.y[:n_batch]
        out = out[:n_batch]
        all_label += label.data
        all_pred += out
        loss = loss_fn(out, label)
        ave_loss += loss.item() * n_batch
        cnt += n_batch
    ave_loss /= cnt
    all_label = torch.stack(all_label)
    all_pred = torch.stack(all_pred)
    metrics, plog = calc_metrics(all_label, all_pred)
    plog = 'Epoch-{} {} loss: {:.6}'.format(epoch, name, ave_loss) + plog
    if args.detail:
        print(plog)
    if pretrained == True:
        return metrics,pretrained_embeddings
    else:
        return metrics

def train(seed,mode,train_set,val_set,test_set,j):
    print(mode)

    train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_set, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_set, batch_size=batch_size, shuffle=False)


    if  mode=='HeteroBotGCN':
        model = HeteroBotGCN(hidden_dim=hidden_dim,
                             dropout=dropout,
                             num_prop_size=data.num_property_embedding.shape[-1],
                             cat_prop_size=data.cat_property_embedding.shape[-1],  # ,
                             num_relations=data.edge_type.max().item() + 1).to(device)
    elif mode == 'GAT':

        model = BotGAT(hidden_dim=hidden_dim,
                       dropout=dropout,
                       num_prop_size=data.num_property_embedding.shape[-1],
                       cat_prop_size=data.cat_property_embedding.shape[-1]).to(device)
    elif mode == 'GCN':
        model = BotGCN(hidden_dim=hidden_dim,
                       dropout=dropout,
                       num_prop_size=data.num_property_embedding.shape[-1],
                       cat_prop_size=data.cat_property_embedding.shape[-1]).to(device)
    elif mode == 'RGCN':
        model = BotRGCN(hidden_dim=hidden_dim,
                        dropout=dropout,
                        num_prop_size=data.num_property_embedding.shape[-1],
                        cat_prop_size=data.cat_property_embedding.shape[-1],#,
                        num_relations=data.edge_type.max().item() + 1).to(device)
    elif mode == 'MeanBotGCN':

        model = MeanBotGCN(hidden_dim=hidden_dim,
                             dropout=dropout,
                             num_prop_size=data.num_property_embedding.shape[-1],
                             cat_prop_size=data.cat_property_embedding.shape[-1],  # ,
                             num_relations=data.edge_type.max().item() + 1).to(device)
    elif mode == 'LayerBotGCN':

        model = LayerBotGCN(hidden_dim=hidden_dim,
                           dropout=dropout,
                           num_prop_size=data.num_property_embedding.shape[-1],
                           cat_prop_size=data.cat_property_embedding.shape[-1],  # ,
                           num_relations=data.edge_type.max().item() + 1).to(device)


    best_val_metrics = null_metrics()
    best_state_dict = None
    weight = 1.3*(1 - data.y[train_index]).float().sum().item() / data.y[train_index].float().sum().item()
    loss_fn = nn.CrossEntropyLoss(weight=torch.tensor([1., weight]).to(device))
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    pbar = tqdm(range(max_epoch), ncols=0)
    cnt = 0

    for epoch in pbar:
        start = time.time()
        val_metrics = forward_one_epoch(epoch, model, optimizer, loss_fn, train_loader, val_loader)

        if args.detail:
            print(val_metrics)
            print(f"******the cost in one_epoch is : {time.time() - start}s")

        if is_better(val_metrics, best_val_metrics):
            best_val_metrics = val_metrics
            best_state_dict = model.state_dict()
            torch.save(best_state_dict, 'saved_model/{}_{}_{}.pt'.format(mode, str(seed), 'user' + str(j)))
            cnt = 0
        else:
            cnt += 1
        if args.detail:
            pbar.set_postfix_str('val acc {} no up cnt {}'.format(val_metrics['acc'], cnt))
        if cnt == no_up:
            break

    best_state_dict = torch.load('saved_model/{}_{}_{}.pt'.format(mode, str(seed), 'user' + str(j)))
    model.load_state_dict(best_state_dict)

    test_metrics = validation(max_epoch, 'test', model, loss_fn, test_loader)
    print('*'*40)
    print(test_metrics)
    return epoch



if __name__ == '__main__':

    mode = ['HeteroBotGCN']
    for model_name in mode:

        for i in range(4):
            set_seed(i)
            epoch = train(i, model_name,train_set,val_set,test_set,0)
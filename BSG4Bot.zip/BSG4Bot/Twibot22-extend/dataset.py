import os
import random
import torch
import os.path as osp
from torch_geometric.data import Data

def get_train_data(dataset_name,args):
    if dataset_name == 'Twibot-20':
        path = '../../processed_data_20'
    else:
        path = '../../processed_data'
    if not osp.exists(path):
        raise KeyError
    labels = torch.load(osp.join(path, 'label.pt'))
    print(len(labels))


    des_embedding = torch.load(osp.join(path, 'des_tensor.pt')).contiguous()
    tweet_embedding = torch.load(osp.join(path, 'tweets_tensor_new.pt')).contiguous()
    num_property_embedding = torch.load(osp.join(path, 'num_properties_tensor.pt')).contiguous()
    cat_property_embedding = torch.load(osp.join(path, 'cat_properties_tensor.pt')).contiguous()
    print(des_embedding.shape,tweet_embedding.shape,num_property_embedding.shape,cat_property_embedding.shape)
    edge_index = torch.load(osp.join(path, 'edge_index.pt')).contiguous()
    edge_type = torch.load(osp.join(path, 'edge_type.pt')).contiguous()



    if dataset_name == 'Twibot-20':
        random_values = torch.randint(0, 2, (217754,), dtype=torch.long)
        labels = torch.cat([labels, random_values])
        train_idx = torch.arange(0, 8278)
        val_idx = torch.arange(8278, 8278 + 2365)
        test_idx = torch.arange(8278+2365, 8278 + 2365 + 1183)
        pre_trained_test_idx=torch.arange(0,229580)
    else:

        train_idx = torch.load(osp.join(path, 'train_idx.pt'))
        val_idx = torch.load(osp.join(path, 'val_idx.pt'))
        test_idx = torch.load(osp.join(path, 'test_idx.pt'))
        pre_trained_test_idx=torch.cat((train_idx, val_idx, test_idx), dim=0)

    data=Data(edge_index=edge_index,
                edge_type=edge_type,
                y=labels,
                des_embedding=des_embedding,
                tweet_embedding=tweet_embedding,
                num_property_embedding=num_property_embedding,
                cat_property_embedding=cat_property_embedding,
                train_idx=train_idx,
                val_idx=val_idx,
                test_idx=test_idx,
                pre_trained_test_idx=pre_trained_test_idx,
                num_nodes=des_embedding.shape[0])
    if args.extend:
            data = dataset_timesteps_expand(data, args)
    return data



def add_noise(tensor, noise_factor=0.05):
    mean = tensor.mean(dim=0, keepdim=True)
    std = tensor.std(dim=0, keepdim=True) + 1e-6  
    noise = torch.randn_like(tensor) * std * noise_factor
    return tensor + noise

def dataset_timesteps_expand(data, args):

    original_num_nodes = data.num_nodes
    original_edges = data.edge_index
    original_labels = data.y

    e_labels = original_labels.repeat(args.factor, )

    e_des_embedding = torch.cat(
        [data.des_embedding] + [add_noise(data.des_embedding) for _ in range(args.factor - 1)], dim=0
    )
    e_tweet_embedding = torch.cat(
        [data.tweet_embedding] + [add_noise(data.tweet_embedding) for _ in range(args.factor - 1)], dim=0
    )
    e_num_property_embedding = torch.cat(
        [data.num_property_embedding] + [add_noise(data.num_property_embedding) for _ in range(args.factor - 1)], dim=0
    )
    e_cat_property_embedding = torch.cat(
        [data.cat_property_embedding] + [add_noise(data.cat_property_embedding) for _ in range(args.factor - 1)], dim=0
    )

    e_edge_type = data.edge_type.repeat(args.factor, )

    current_num_nodes = data.num_nodes * args.factor

    total_edge = original_edges

    for i in range(1, args.factor):
        new_edge_index = original_edges.clone()
        new_edge_index = new_edge_index + i * original_num_nodes
        total_edge = torch.cat((total_edge, new_edge_index), dim=1)

    bot_index = torch.nonzero(e_labels  ==1)
    human_index = torch.nonzero(e_labels==0)
    bot_ratio = bot_index.shape[0]  / e_labels.shape[0]

    type0_index = torch.nonzero(e_edge_type  ==0)
    type1_index = torch.nonzero(e_edge_type  ==1)
    type0_ratio = type0_index.shape[0]  / e_edge_type.shape[0]


    num_new_edges = total_edge.size(1) * args.new_edge_ratio

    new_edge_list = []

    bot_to = int (bot_ratio * num_new_edges )
    human_to = num_new_edges - bot_to

    bot_to_bot = int (bot_to * (1 - args.bot_2_human))
    bot_to_human = int(bot_to * args.bot_2_human)

    for i in range(bot_to_bot):
        source = bot_index[random.randint(0, len(bot_index) -1)].item()
        target = bot_index[random.randint(0, len(bot_index) -1)].item()
        new_edge_list.append((source, target))

    for i in range(bot_to_human):
        source = bot_index[random.randint(0, len(bot_index) -1)].item()
        target = human_index[random.randint(0, len(human_index) -1)].item()
        new_edge_list.append((source, target))

    human_to_bot = int (human_to * args.human_2_bot)
    human_to_human = int (human_to * (1- args.human_2_bot))

    for i in range(human_to_bot):
        source = human_index[random.randint(0, len(human_index) -1)].item()
        target = bot_index[random.randint(0, len(bot_index) -1)].item()
        new_edge_list.append((source, target))

    for i in range(human_to_human):
        source = human_index[random.randint(0, len(human_index) -1)].item()
        target = human_index[random.randint(0, len(human_index) -1)].item()
        new_edge_list.append((source, target))

    new_edge_type_list = []
    for i in range(len(new_edge_list)):
        if random.random() < type0_ratio:
            new_edge_type_list.append(0)
        else:
            new_edge_type_list.append(1)


    total_edge = torch.cat((total_edge, torch.tensor(new_edge_list, dtype=torch.int).T), dim=1)
    total_edge_type = torch.cat((e_edge_type, torch.tensor(new_edge_type_list, dtype=torch.int).T), dim=0)

    data_extend = Data(
        edge_index=total_edge,
        edge_type=total_edge_type,
        y=e_labels,
        des_embedding=e_des_embedding,
        tweet_embedding=e_tweet_embedding,
        num_property_embedding=e_num_property_embedding,
        cat_property_embedding=e_cat_property_embedding,
        num_nodes=current_num_nodes,
        node_num_origin = original_num_nodes ,
    )

    if args.pretrained:
        pretrained_results = torch.load(osp.join('pretrained/pretrained_embedding.pt')).contiguous()
        data_extend['pretrained_results'] = pretrained_results
    return data_extend
